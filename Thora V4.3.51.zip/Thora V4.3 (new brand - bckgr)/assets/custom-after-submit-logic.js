const DEBUG_REQUIRE_ON_SUBMIT = false;
// Product / Module is now set correctly by Zendesk after the organization-field fix.
// Keep this enabled to prevent the legacy n8n correction call for field 28175955127324.
const DISABLE_PRODUCT_MODULE_N8N_UPDATE = true;
const DEBUG_PRODUCT_MODULE_RAW_TICKET_API = true;

const FIELDS_BY_TYPE = {
  "Transaction Processing SI Logged": [
    {
      name: "End Time (UTC)",
      type: "text",
      zid: 23677140564508,
      required: false,
    },

    {
      name: "Transaction Types",
      type: "multichoice",
      zid: 13190791381148,
      required: false,
      options: [
        { label: "ATM", tag: "transaction-types_atm" },
        {
          label: "Credential-on-file",
          tag: "transaction-types_credential-on-file",
        },
        { label: "ECOM", tag: "transaction-types_ecom" },
        { label: "POS", tag: "transaction-types_pos" },
      ],
    },
  ],
  "Inbound API (VE) SI Logged": [
    {
      name: "Connection Issue",
      type: "dropdown",
      zid: 23677089625372,
      required: true,
      options: [
        { label: "Yes", value: "connection-issue_yes" },
        { label: "No", value: "connection-issue_no" },
      ],
    },
    // {
    //   name: "Impacted API (VE)",
    //   type: "dropdown",
    //   zid: 31356178976285,
    //   required: true,
    //   options: [
    //     // TODO id ul e de sandbo, de vazut daca devine text din dropdown [FOR LATER]
    //     { label: "api 1", value: "api_1_clone" },
    //     { label: "api 2", value: "api_2_clone" },
    //     { label: "api 3", value: "api_3_clone" },
    //   ],
    // },
    {
      name: "Impacted API (VE)",
      type: "text",
      zid: 23677180468764,
      required: true,
    },
    {
      name: "Observed Start Time (UTC)",
      type: "text",
      zid: 23677132759580,
      required: true,
    },
    {
      name: "Error Code",
      type: "multichoice",
      zid: 23676987219484,
      required: false,
      options: [
        { label: "400", value: "400" },
        { label: "401", value: "401" },
        { label: "404", value: "404" },
      ],
    },
  ],
  "Inbound API (BL) SI Logged": [
    {
      name: "Error Code",
      type: "multichoice",
      zid: 23676987219484,
      required: false,
      options: [
        { label: "400", value: "400" },
        { label: "401", value: "401" },
        { label: "404", value: "404" },
      ],
    },
    {
      name: "Connection Issue",
      type: "dropdown",
      zid: 23677089625372,
      required: true,
      options: [
        { label: "Yes", value: "connection-issue_yes" },
        { label: "No", value: "connection-issue_no" },
      ],
    },
    // {
    //   name: "Impacted API (BL)",
    //   type: "dropdown",
    //   zid: 23677172391452,
    //   required: true,
    //   options: [
    //     // TODO de vazut daca fac text sau las dropdown
    //     { label: "api 1", value: "api_1" },
    //     { label: "api 2", value: "api_2" },
    //     { label: "api 3", value: "api_3" },
    //   ],
    // },
    {
      name: "Impacted API (BL)",
      type: "text",
      zid: 23677172391452,
      required: true,
    },
    {
      name: "Observed Start Time (UTC)",
      type: "text",
      zid: 23677132759580,
      required: true,
    },
    {
      name: "End Time (UTC)",
      type: "text",
      zid: 23677140564508,
      required: true,
    },
  ],
  "Reports / Files SI Logged": [
  ],
  "Digitalisation SI Logged": [
    {
      name: "Trace ID(s)",
      type: "textarea",
      zid: 23677004152604,
      required: false,
    },
    {
      name: "Digitalisation Error",
      type: "text",
      zid: 23676999908636,
      required: false,
    },
  ],
};

const FIELDS_SHOWN_ON_INCIDENT_TYPES = {
  "Transaction Processing SI Logged": [
    { name: "Transaction Impact", zid: 23677306298524 },
    { name: "Affected Scheme", zid: 23677211046556 },
    { name: "Transaction ID(s)", zid: 23677215518876 },
    { name: "Observed Start Time (UTC)", zid: 23677132759580 },
    { name: "Observed End Time (UTC)", zid: 23677140564508 },
    { name: "Transaction Types", zid: 13190791381148 },
    { name: "Priority" },
    { name: "Assigned to" },
    { name: "Last activity" },
    { name: "Created" },
    { name: "Requester" },
  ],
  "Inbound API (VE) SI Logged": [
    { name: "Affected API", zid: 23677272409372 },
    { name: "API Impact", zid: 26052682743708 },
    { name: "Is it a Connection Issue?", zid: 23677089625372 },
    { name: "Impacted API (VE)", zid: 23677180468764 },
    { name: "Observed Start Time (UTC)", zid: 23677132759580 },
    { name: "Error Code", zid: 23676987219484 },
    { name: "Priority" },
    { name: "Assigned to" },
    { name: "Last activity" },
    { name: "Created" },
    { name: "Requester" },
  ],
  "Inbound API (BL) SI Logged": [
    { name: "Affected API", zid: 23677272409372 },
    { name: "API Impact", zid: 26052682743708 },
    { name: "Error Code", zid: 23676987219484 },
    { name: "Connection Issue", zid: 23677089625372 },
    { name: "Impacted API (BL)", zid: 23677172391452 },
    { name: "Observed Start Time (UTC)", zid: 23677132759580 },
    { name: "End Time (UTC)", zid: 23677140564508 },
    { name: "Priority" },
    { name: "Assigned to" },
    { name: "Last activity" },
    { name: "Created" },
    { name: "Requester" },
  ],
  "Reports / Files SI Logged": [
    { name: "Impacted Report", zid: 23677086187036 },
    { name: "Report Date / Time (UTC)", zid: 23677070972956 },
    { name: "Connection Issue", zid: 23677089625372 },
    { name: "Priority" },
    { name: "Assigned to" },
    { name: "Last activity" },
    { name: "Created" },
    { name: "Requester" },
  ],
  "Digitalisation SI Logged": [
    { name: "Digitilisation Services Impacted", zid: 23677240208028 },
    { name: "Digitalisation Impact", zid: 23677214406300 },
    { name: "Affected Scheme", zid: 23677211046556 },
    { name: "Affected Digitalisation Service", zid: 23677198854940 },
    { name: "Impacted Wallet", zid: 23677121919132 },
    { name: "Observed Start Time (UTC)", zid: 23677132759580 },
    { name: "Manual Provisioning Working", zid: 23676989810972 },
    { name: "End Time (UTC)", zid: 23677140564508 },
    { name: "Trace ID(s)", zid: 23677004152604 },
    { name: "Digitalisation Error", zid: 23676999908636 },
    { name: "Priority" },
    { name: "Assigned to" },
    { name: "Last activity" },
    { name: "Created" },
    { name: "Requester" },
  ],
};

//Entry point for Service Incident logic
if (/\/requests\/\d+/.test(location.pathname)) {
  const fields = JSON.parse(localStorage.getItem("custom_fields") || "[]");
  if (DEBUG_REQUIRE_ON_SUBMIT) console.log("custom_fields =", fields);
  const has = fields.some(
    (f) => f.title === "Impacted Service Area" && (f.value || "").trim() !== "—"
  );
  const productModuleField = fields.find(
    (f) => f.title === "Product / Module" && (f.value || "").trim() !== "—"
  );
  const submittedProductModule =
    sessionStorage.getItem("pending_product_module_value") ||
    productModuleField?.value ||
    "";
  const ticketIdForProductModule =
    (location.pathname.match(/\/requests\/(\d+)/) || [])[1];
  console.log("[Product / Module DEBUG] created ticket snapshot", JSON.stringify({
    ticketId: ticketIdForProductModule || null,
    snapshotValue: productModuleField?.value || "",
    sessionSubmitValue: sessionStorage.getItem("pending_product_module_value") || "",
    valueSelectedForCorrection: submittedProductModule,
  }, null, 2));

  if (DEBUG_PRODUCT_MODULE_RAW_TICKET_API && ticketIdForProductModule) {
    (async () => {
      const rawTicketResponse = await fetch(
        `/api/v2/tickets/${encodeURIComponent(ticketIdForProductModule)}.json`,
        { credentials: "include" }
      );
      const rawTicketText = await rawTicketResponse.text();
      let rawTicketJson = null;
      try {
        rawTicketJson = JSON.parse(rawTicketText);
      } catch (error) {
        // Preserve the raw response below when it is not JSON.
      }
      const rawTicket = rawTicketJson?.ticket || null;
      const rawProductModuleField = Array.isArray(rawTicket?.custom_fields)
        ? rawTicket.custom_fields.find((field) => field.id === 28175955127324)
        : null;
      console.log("[Product / Module DEBUG] raw ticket API response", JSON.stringify({
        ticketId: ticketIdForProductModule,
        status: rawTicketResponse.status,
        ok: rawTicketResponse.ok,
        rawProductModuleField,
        rawTicketCustomFields: rawTicket?.custom_fields || null,
        rawResponse: rawTicketJson || rawTicketText,
      }, null, 2));
    })().catch((error) => {
      console.warn("[Product / Module DEBUG] raw ticket API request failed", error);
    });
  }
  const productModuleWebhookKey = `product_module_webhook_sent_${ticketIdForProductModule}`;
  if (!DISABLE_PRODUCT_MODULE_N8N_UPDATE && !has && submittedProductModule && ticketIdForProductModule &&
      !sessionStorage.getItem(productModuleWebhookKey)) {
    sessionStorage.setItem(productModuleWebhookKey, "true");
    N8N_UpdateTicket(ticketIdForProductModule, {
        customFields: [{
          id: 28175955127324,
          value: submittedProductModule,
        }],
    }).then((result) => {
      console.log("[Product / Module] Zendesk field update response", result);
    }).catch((error) => {
      sessionStorage.removeItem(productModuleWebhookKey);
      console.warn("[Product / Module] Zendesk field update failed", error);
    });
    sessionStorage.removeItem("pending_product_module_value");
  }
  if (!DISABLE_PRODUCT_MODULE_N8N_UPDATE && has && submittedProductModule && ticketIdForProductModule) {
    N8N_UpdateTicket(ticketIdForProductModule, {
      customFields: [{
        id: 28175955127324,
        value: submittedProductModule,
      }],
    }).then((result) => {
      console.log("[Incident Product / Module] Zendesk field update response", result);
      sessionStorage.removeItem("pending_product_module_value");
    }).catch((error) => {
      console.warn("[Incident Product / Module] Zendesk field update failed", error);
    });
  }
  if (DEBUG_REQUIRE_ON_SUBMIT)
    console.log("Impacted Service Area detected:", has);
  if (has) {
    //Logic for Service Incident
    serviceIncidentMain(fields);
  }
}

// === 2) HELPERS: Zendesk API interaction ===

async function N8N_UpdateTicket(
  ticketId,
  { subject, priority, customFields } = {}
) {
  let custom_fields = [];
  if (Array.isArray(customFields)) {
    custom_fields = customFields;
  } else if (customFields && typeof customFields === "object") {
    custom_fields = Object.entries(customFields).map(([id, value]) => ({
      id: Number(id),
      value,
    }));
  }

  const payload = { ticket: {} };
  if (subject !== undefined) payload.ticket.subject = subject;
  if (priority !== undefined) payload.ticket.priority = priority; // "low" | "normal" | "high" | "urgent"
  if (custom_fields.length) payload.ticket.custom_fields = custom_fields;

  if (DEBUG_PRODUCT_MODULE_RAW_TICKET_API) {
    try {
      const beforeUpdateResponse = await fetch(
        `/api/v2/tickets/${encodeURIComponent(ticketId)}.json`,
        { credentials: "include" }
      );
      const beforeUpdateText = await beforeUpdateResponse.text();
      const beforeUpdateJson = JSON.parse(beforeUpdateText);
      const beforeUpdateField = beforeUpdateJson?.ticket?.custom_fields?.find(
        (field) => field.id === 28175955127324
      );
      console.log("[Product / Module DEBUG] raw ticket immediately before n8n update", JSON.stringify({
        ticketId,
        status: beforeUpdateResponse.status,
        ok: beforeUpdateResponse.ok,
        currentProductModuleField: beforeUpdateField || null,
        requestedUpdate: custom_fields.find((field) => field.id === 28175955127324) || null,
      }, null, 2));
    } catch (error) {
      console.warn("[Product / Module DEBUG] pre-update ticket API read failed", error);
    }
  }

  const { token } = await fetch("/api/v2/help_center/integration/token.json", {
    credentials: "include",
  }).then((r) => r.json());
  const r = await fetch(
    "https://dbxijaghk4zve.cloudfront.net/webhook/1bf487e8-3293-4507-b52a-86a8a706e438/update",
    {
      method: "POST",
      mode: "cors",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`, // important
      },
      body: JSON.stringify({ ticketId: ticketId, payload: payload }),
    }
  );
  console.warn("test", r);

  if (!r.ok) {
    console.error("Error UPDATE ticket:", r.status, await r.text());
    return null;
  }

  const responseText = await r.text();
  let data;
  try {
    data = JSON.parse(responseText);
  } catch (error) {
    console.error("Invalid n8n update response:", responseText);
    return null;
  }
  if (DEBUG_PRODUCT_MODULE_RAW_TICKET_API) {
    console.log("[Product / Module DEBUG] n8n update response", JSON.stringify({
      status: r.status,
      ok: r.ok,
      response: data,
    }, null, 2));
  }
  if (DEBUG_REQUIRE_ON_SUBMIT) console.log("TICKET:", data.ticket);
  return data.ticket;
}

// === FIELD HELPERS ===

function injectCountdownNotice(targetId, creationDate) {
  const el = document.querySelector(targetId);
  if (!el) return;

  // Apply base styles via CSS class
  el.classList.add("countdown-notice");

  // Icon element with class-based styling
  const icon = `<svg xmlns="http://www.w3.org/2000/svg" height="28" width="28" class="countdown-notice__icon" viewBox="0 0 24 24">
                    <path d="M11.99 2C6.47 2 2 6.48 2 12s4.47 10 9.99 10C17.52 22 22 17.52 22 12S17.52 2 11.99 2m3.3 14.71L11 12.41V7h2v4.59l3.71 3.71z" fill="#ffffff" />
                  </svg>`;

  const deadline = creationDate.getTime() + 15 * 60 * 1000;
  let timer;

  const tick = () => {
    const left = Math.floor((deadline - Date.now()) / 1000);
    if (left <= 0) {
      // Switch to expired state via CSS modifier class
      el.classList.add("countdown-notice--expired");
      el.innerHTML = `${icon}<span>Time expired. Your request has been submitted without additional details and may be processed with lower priority.</span>`;
      clearInterval(timer);
      return;
    }
    const m = (left / 60) | 0,
      s = left % 60;
    el.innerHTML = `${icon}<span><strong>You have ${m}:${String(s).padStart(2, "0")}</strong> minute(s) to submit additional details to avoid delays in response or deprioritisation of your request.</span>`;
  };

  tick();
  timer = setInterval(tick, 1000);
  return () => clearInterval(timer);
}

function slugify(str) {
  return String(str)
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/(^-|-$)/g, "");
}

// All builder functions now use template literals and do not depend on any template cache system.
function buildTextField(fieldConfig) {
  const id = slugify(fieldConfig.name);
  const zid = fieldConfig.zid || id; // ID Zendesk numeric, dacă există
  const zdId = `request_custom_fields_${zid}`; // id/clasă în stil Zendesk
  const statusClass = fieldConfig.required ? "required" : "optional";
  const zidAttr = fieldConfig.zid ? ` data-zid="${fieldConfig.zid}"` : "";
  // const optionalSpan = fieldConfig.required ? '' : '<span class="optional">(optional)</span>';
  const valueAttr =
    "value" in fieldConfig
      ? ` value="${String(fieldConfig.value ?? "")}"`
      : ' value=""';

  const html = `
    <div class="form-field string ${statusClass} ${zdId}">
      <label id="${zdId}_label" for="${zdId}">
        ${fieldConfig.name}
      </label>
      <input
        type="text"
        name="request[custom_fields][${zid}]"
        id="${zdId}"${valueAttr}
        aria-required="${fieldConfig.required ? "true" : "false"}"${fieldConfig.required ? " required" : ""}
        aria-labelledby="${zdId}_label"
        data-name="${fieldConfig.name}"${zidAttr}>
    </div>
  `;
  return html.trim();
}

function buildTextAreaField(fieldConfig) {
  const id = slugify(fieldConfig.name);
  const zid = fieldConfig.zid || id; // ID-ul Zendesk numeric, dacă există
  const zdId = `request_custom_fields_${zid}`; // id/clasă în stil Zendesk
  const statusClass = fieldConfig.required ? "required" : "optional";
  const zidAttr = fieldConfig.zid ? ` data-zid="${fieldConfig.zid}"` : "";
  // const optionalSpan = fieldConfig.required ? '' : '<span class="optional">(optional)</span>';

  const html = `
    <div class="form-field text ${statusClass} ${zdId}">
      <label id="${zdId}_label" for="${zdId}">
        ${fieldConfig.name}
      </label>
      <textarea
        name="request[custom_fields][${zid}]"
        id="${zdId}"
        aria-required="${fieldConfig.required ? "true" : "false"}"${fieldConfig.required ? " required" : ""}
        aria-labelledby="${zdId}_label"
        data-name="${fieldConfig.name}"${zidAttr}></textarea>
    </div>
  `;
  return html.trim();
}

function buildDropdownField(fieldConfig) {
  const esc = (s) =>
    String(s ?? "")
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;");

  const zid = fieldConfig.zid ?? slugify(fieldConfig.name);
  const base = `request_custom_fields_${zid}`;
  const name = `request[custom_fields][${zid}]`;
  const req = !!fieldConfig.required;
  const labelText = esc(fieldConfig.label || fieldConfig.name || "");

  const src = Array.isArray(fieldConfig.options) ? fieldConfig.options : [];
  const opts = src.map((o) =>
    typeof o === "string"
      ? { label: o, value: o, selected: false }
      : {
          label: o.label ?? o.name ?? String(o.value ?? o.id ?? o.tag ?? ""),
          value: String(o.value ?? o.id ?? o.tag ?? o.name ?? ""),
          selected: !!o.selected,
        }
  );

  const placeholder =
    fieldConfig.placeholder === false ? null : { label: "-", value: "" };
  const all = placeholder ? [placeholder, ...opts] : opts;

  const selectedValue =
    fieldConfig.value != null
      ? String(fieldConfig.value)
      : (opts.find((o) => o.selected)?.value ?? "");

  const selectedLabel =
    all.find((o) => o.value === selectedValue)?.label ??
    (placeholder ? "-" : (opts[0]?.label ?? "Select…"));

  const dataTagger = JSON.stringify(
    all.map((o) => ({
      label: o.label,
      value: o.value,
      selected: o.value === selectedValue,
    }))
  );

  const menuId = `_${Math.random().toString(36).slice(2)}`;
  const anchorId = `${base}_nesty`;

  const listItems = all
    .map((o) => {
      const t = esc(o.label),
        v = esc(o.value);
      const isSel = o.value === selectedValue;
      const shown = t !== "-" && isSel ? `<strong>${t}</strong>` : t;
      return `<li role="option"><a href="javascript:" data-value="${v}">${shown}</a></li>`;
    })
    .join("");

  return `
<div class="form-field string request_custom_fields_${esc(zid)}${req ? " required" : ""}">
  <label id="${base}_label" for="${base}">${labelText}</label>

  <input type="hidden" name="${esc(name)}" id="${base}"
         value="${esc(selectedValue)}" autocomplete="off"
         data-tagger='${esc(dataTagger)}'
         aria-required="${req ? "true" : "false"}" aria-labelledby="${base}_label">

  <a id="${anchorId}" class="nesty-input" tabindex="0" aria-haspopup="true"
     aria-expanded="false" aria-controls="${menuId}"
     aria-required="${req ? "true" : "false"}" aria-labelledby="${base}_label"
     style="max-width:100%;"
     onclick="(function(a){
       var panel = document.getElementById('${menuId}');
       if (!panel.__inBody) { document.body.appendChild(panel); panel.__inBody=1; panel.style.position='absolute'; panel.style.zIndex='1000'; }
       var open = a.getAttribute('aria-expanded')==='true';
       if (!open){
         var r=a.getBoundingClientRect();
         panel.style.minWidth = r.width+'px';
         panel.style.left = (window.scrollX + r.left)+'px';
         panel.style.top  = (window.scrollY + r.bottom)+'px';
         panel.style.display='block';
         a.setAttribute('aria-expanded','true');
         var closer=function(ev){
           if (ev && ev.type==='keydown' && ev.key!=='Escape') return;
           if (ev && ev.type==='click' && (panel.contains(ev.target)||a.contains(ev.target))) return;
           a.setAttribute('aria-expanded','false'); panel.style.display='none';
           document.removeEventListener('click', closer, true);
           window.removeEventListener('scroll', closer, true);
           window.removeEventListener('resize', closer, true);
           document.removeEventListener('keydown', closer, true);
         };
         document.addEventListener('click', closer, true);
         window.addEventListener('scroll', closer, true);
         window.addEventListener('resize', closer, true);
         document.addEventListener('keydown', closer, true);
       } else { a.setAttribute('aria-expanded','false'); panel.style.display='none'; }
     })(this)"
     onkeydown="(function(a,e){
       var k=e.key; if(k==='Enter'||k===' '||k==='ArrowDown'){ e.preventDefault(); a.click(); }
       if(k==='Escape'){ var p=document.getElementById('${menuId}'); a.setAttribute('aria-expanded','false'); p.style.display='none'; }
     })(this,event)">${esc(selectedLabel)}</a>

  <div id="${menuId}" class="nesty-panel" role="listbox" data-anchor="${anchorId}" style="display:none;">
    <ul class="nesty-list"
        onclick="(function(e,ul){
          var link=e.target.closest('a'); if(!link) return; e.preventDefault();
          var panel=ul.parentNode, anchor=document.getElementById(panel.getAttribute('data-anchor'));
          var hidden=document.getElementById('${base}');
          hidden.value = link.dataset.value;
          anchor.textContent = link.textContent.trim();
          hidden.dispatchEvent(new Event('change', { bubbles: true }));
          ul.querySelectorAll('a').forEach(function(x){
            var t=x.textContent.trim(); x.innerHTML = (t!=='-'?t:'-');
          });
          if (link.textContent.trim()!=='-') link.innerHTML='<strong>'+link.textContent.trim()+'</strong>';
          anchor.setAttribute('aria-expanded','false');
          panel.style.display='none';
        })(event,this)">
      ${listItems}
    </ul>
  </div>

</div>`;
}
// <div id="${base}_error" class="notification notification-error notification-inline"></div>  <- for error banner
function buildMultichoiceField(field) {
  const esc = (s) =>
    String(s ?? "")
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;");
  const zid = field.zid; // Zendesk field id (obligatoriu ca să meargă stylingul temei)
  const base = `request_custom_fields_${zid}`;
  const name = `request[custom_fields][${zid}][]`;
  const required = !!field.required;
  const selected = new Set((field.value || field.selected || []).map(String));

  // opțiuni
  const opts = (field.options || [])
    .map((o) => {
      const val =
        typeof o === "string" ? o : (o.value ?? o.id ?? o.tag ?? o.name ?? "");
      const lab = typeof o === "string" ? o : (o.label ?? o.name ?? val);
      const on = selected.has(String(val));
      return `
      <li tabindex="-1" role="menuitemcheckbox" aria-checked="${on ? "true" : "false"}">
        <label>
          <input value="${esc(val)}" tabindex="-1" type="checkbox"${on ? " checked" : ""} 
            onchange="(function(cb){
              var r=cb.closest('.hc-multiselect'),
                  ul=r.querySelector('ul.hc-selected'),
                  hid=r.querySelector('.hc-hidden');
              ul.innerHTML=''; hid.innerHTML='';
              r.querySelectorAll('.hc-multiselect-menu input[type=checkbox]').forEach(function(c){
                var li, h, txt;
                if(c.checked){
                  txt=c.parentNode.textContent.trim();
                  li=document.createElement('li'); li.setAttribute('role','option');
                  li.innerHTML='<span>'+txt+'</span><a href=javascript: aria-label=Remove>×</a>';
                  li.querySelector('a').onclick=function(e){e.preventDefault(); c.checked=false; c.dispatchEvent(new Event('change'));};
                  ul.appendChild(li);
                  h=document.createElement('input'); h.type='hidden'; h.name=r.dataset.name; h.value=c.value; hid.appendChild(h);
                }
              });
              var ph=r.querySelector('.hc-placeholder'); ph.style.display=ul.children.length?'none':'';
            })(this)">
          ${esc(lab)}
        </label>
      </li>`;
    })
    .join("");

  // chips & hidden inițial
  const chips = [];
  const hidden = [];
  (field.options || []).forEach((o) => {
    const val =
      typeof o === "string" ? o : (o.value ?? o.id ?? o.tag ?? o.name ?? "");
    const lab = typeof o === "string" ? o : (o.label ?? o.name ?? val);
    if (selected.has(String(val))) {
      chips.push(
        `<li role="option">
           <span>${esc(lab)}</span>
           <a href="javascript:" aria-label="Remove"
              onclick="(function(a){var r=a.closest('.hc-multiselect');var cb=[].find.call(r.querySelectorAll('.hc-multiselect-menu input'),function(x){return x.value==='${esc(val)}'}); if(cb){cb.checked=false; cb.dispatchEvent(new Event('change'));}})(this)">×</a>
         </li>`
      );
      hidden.push(
        `<input type="hidden" name="${esc(name)}" value="${esc(val)}">`
      );
    }
  });

  return `
<div class="form-field request_custom_fields_${esc(zid)}${required ? " required" : ""}">
  <label id="${base}_label" for="${base}">${esc(field.label || field.name || "")}</label>

  <div class="hc-multiselect" data-name="${esc(name)}">
    <div class="hc-multiselect-toggle" tabindex="0" id="${base}"
         role="listbox" aria-haspopup="true" aria-expanded="${chips.length ? "true" : "false"}"
         aria-required="${required ? "true" : "false"}"
         aria-describedby="${base}_error" aria-labelledby="${base}_label"
         onclick="(function(el){var m=el.parentNode.querySelector('.hc-multiselect-menu');var open=m.style.display==='block'; m.style.display=open?'':'block'; el.setAttribute('aria-expanded',(!open).toString());})(this)">
      <ul class="hc-selected" role="listbox" aria-labelledby="${base}_label">${chips.join("")}</ul>
      <span class="hc-placeholder"${chips.length ? ' style="display:none"' : ""}>Select…</span>
    </div>

    <div class="hc-multiselect-menu" style="display:${chips.length ? "block" : ""}">
      <ul role="listbox">
        ${opts}
      </ul>
    </div>

    <div class="hc-hidden">
      ${hidden.join("")}
    </div>
  </div>
</div>`;
}

function buildField(fieldConfig) {
  switch (fieldConfig.type) {
    case "text":
      return buildTextField(fieldConfig);
    case "textarea":
      return buildTextAreaField(fieldConfig);
    case "dropdown":
      return buildDropdownField(fieldConfig);
    case "multichoice":
      return buildMultichoiceField(fieldConfig);
    default:
      console.warn("[buildField] Unknown field type:", fieldConfig.type);
      // console.log('[buildField] Field config:', fieldConfig);
      return "";
  }
}

function hideUnwantedFields(incidentType) {
  const allowed = new Set(
    (FIELDS_SHOWN_ON_INCIDENT_TYPES[incidentType] || []).map((x) => x.name)
  );

  document.querySelectorAll("dt.col-12").forEach((dt) => {
    const label = dt.textContent.trim().replace(/:$/, "");
    if (!allowed.has(label)) {
      (dt.parentElement || dt.closest("div")).style.display = "none";
    }
  });
}

function hideSelectedFieldByName(fieldName) {
  document.querySelectorAll("dt.col-12").forEach((dt) => {
    const label = dt.textContent.trim().replace(/:$/, "");
    if (label === fieldName) {
      (dt.parentElement || dt.closest("div")).style.display = "none";
    }
  });
}

function requireOnSubmit(fields) {
  const requiredFields = fields.filter((f) => f.required);

  // Check if description field has content (works with CKEditor)
  let descriptionValid = false;

  // Try CKEditor content first
  const ckEditorDiv = document.querySelector(
    '[contenteditable="true"][role="textbox"]'
  );
  if (ckEditorDiv) {
    const textContent = ckEditorDiv.innerText || ckEditorDiv.textContent || "";
    descriptionValid = textContent.trim().length > 0;
  } else {
    // Fallback to regular textarea
    const descriptionField = document.querySelector("#request_description");
    descriptionValid = !!(
      descriptionField && descriptionField.value.trim().length > 0
    );
  }

  if (DEBUG_REQUIRE_ON_SUBMIT) {
    console.log("[requireOnSubmit] Description valid:", descriptionValid);
  }

  const requirementsMeet =
    descriptionValid &&
    requiredFields.every((fieldConfig) => {
      const zid = fieldConfig.zid;
      let box;
      const fieldSelector = `#request_custom_fields_${zid}_label`;
      const fieldEl = document.querySelector(fieldSelector);

      if (fieldEl) {
        box = fieldEl.closest(".form-field");
      }

      if (!box) {
        const dataZidEl = document.querySelector(`[data-zid="${zid}"]`);
        if (dataZidEl) box = dataZidEl.closest(".form-field");
      }
      if (!box) {
        const inputEl = document.getElementById(
          `request_custom_fields_${zid}_label`
        );
        if (inputEl)
          box = inputEl.closest(".form-field") || inputEl.parentElement;
      }

      // Log if field not found
      if (!box) {
        if (DEBUG_REQUIRE_ON_SUBMIT) {
          console.log(
            "[requireOnSubmit] Field not found:",
            fieldConfig.name,
            "zid:",
            zid
          );
        }
      }

      // // Robust visibility check
      // if (!box || box.getClientRects().length === 0 || getComputedStyle(box).display === 'none' || getComputedStyle(box).visibility === 'hidden') {
      //     if (DEBUG_REQUIRE_ON_SUBMIT) {
      //         console.log('[requireOnSubmit] Field hidden (ignored):', fieldConfig.name);
      //     }
      //     return true;
      // }

      if (fieldConfig.type === "text" || fieldConfig.type === "textarea") {
        const el =
          document.getElementById(`request_custom_fields_${zid}`) ||
          box.querySelector('input[type="text"], textarea');
        const isValid = !!(el && el.value.trim().length);
        if (DEBUG_REQUIRE_ON_SUBMIT) {
          console.log(
            "[requireOnSubmit] Field:",
            fieldConfig.name,
            "Type:",
            fieldConfig.type,
            "Valid:",
            isValid
          );
        }
        return isValid;
      }
      if (fieldConfig.type === "dropdown") {
        const hid =
          box.querySelector(
            `input[type="hidden"][id="request_custom_fields_${zid}"]`
          ) || document.getElementById(`request_custom_fields_${zid}`);
        const v = (hid?.value || "").trim();
        const isValid = v && v !== "-";
        if (DEBUG_REQUIRE_ON_SUBMIT) {
          console.log(
            "[requireOnSubmit] Field:",
            fieldConfig.name,
            "Type:",
            fieldConfig.type,
            "Valid:",
            isValid
          );
        }
        return isValid;
      }
      if (fieldConfig.type === "multichoice") {
        const isValid = !!box.querySelector(
          'input[type="checkbox"]:checked, input[type="radio"]:checked'
        );
        if (DEBUG_REQUIRE_ON_SUBMIT) {
          console.log(
            "[requireOnSubmit] Field:",
            fieldConfig.name,
            "Type:",
            fieldConfig.type,
            "Valid:",
            isValid
          );
        }
        return isValid;
      }
      if (DEBUG_REQUIRE_ON_SUBMIT) {
        console.log(
          "[requireOnSubmit] Field:",
          fieldConfig.name,
          "Type:",
          fieldConfig.type,
          "Valid: false (unknown type)"
        );
      }
      return false; // default: consideră-necompletat
    });

  if (DEBUG_REQUIRE_ON_SUBMIT)
    console.log(
      "[requireOnSubmit] Total required:",
      requiredFields.length,
      "All valid:",
      requirementsMeet
    );

  // Toggle all submit buttons in the form

  const submits = document.querySelectorAll(
    'input[type="submit"], button[type="submit"], input[type="submit"][name="commit"], button[type="submit"]'
  );
  submits.forEach((submit) => {
    submit.disabled = !requirementsMeet;
  });

  if (DEBUG_REQUIRE_ON_SUBMIT)
    console.log(
      "Requirements meet:",
      requirementsMeet,
      "-> Submit buttons:",
      submits
    );
}

function checkValueExist(fields) {
  let bool = false;
  const requiredFields = fields.filter((f) => f.required);
  requiredFields.some((field) => {
    const colName = Array.from(document.querySelectorAll(".col-12")).find(
      (el) => el.textContent.trim().replace(/:$/, "") === field.name
    );
    const colValue = colName
      ? colName.nextElementSibling &&
        colName.nextElementSibling.classList.contains("col-13")
        ? colName.nextElementSibling.innerHTML
        : ""
      : "";
    if (DEBUG_REQUIRE_ON_SUBMIT)
      console.log("[checkValueExist] Field:", field.name, "Value:", colValue);

    if (colValue && colValue.trim() !== "" && colValue.trim() !== "—") {
      bool = true;
      // Clear the FieldsSent flag once we see actual values from Zendesk
      localStorage.removeItem("FieldsSent");
      localStorage.removeItem("FieldsSentTimestamp");
      return true;
    }
  });

  // If no values found in DOM, check if fields were recently sent to N8N
  if (!bool) {
    const fieldsSent = localStorage.getItem("FieldsSent") === "true";
    const sentTimestamp = parseInt(
      localStorage.getItem("FieldsSentTimestamp") || "0"
    );
    const timeSinceSent = Date.now() - sentTimestamp;

    // Grace period: 30 seconds for N8N to update Zendesk
    if (fieldsSent && timeSinceSent < 30000) {
      if (DEBUG_REQUIRE_ON_SUBMIT)
        console.log(
          "[checkValueExist] Fields sent to N8N recently, skipping injection (grace period)"
        );
      return true; // Pretend fields exist, don't inject form
    } else if (fieldsSent && timeSinceSent >= 30000) {
      // Timeout exceeded, clear flags and allow re-injection
      if (DEBUG_REQUIRE_ON_SUBMIT)
        console.log("[checkValueExist] Grace period expired, clearing flags");
      localStorage.removeItem("FieldsSent");
      localStorage.removeItem("FieldsSentTimestamp");
    }
  }

  return bool;
}

function serviceIncidentMain(fields) {
  // 1. Extract ticket ID from URL
  const ticketId = Number(
    (location.pathname.match(/\/requests\/(\d+)(?:\/|$)/) || [])[1] || null
  );

  // 2. Initialize HTML with header
  let html = '<h3 class="font-size-1xl">Service Incident - Step 2</h3>';

  // 3. Find incident type from fields array
  const getResolvedIncidentType = (customFields) => {
    const storedIncidentType = (
      customFields.find(
        (field) => field.title === "Incident Submission Status"
      ) || {}
    ).value;

    if (storedIncidentType && storedIncidentType !== "—") {
      return storedIncidentType;
    }

    const serviceArea = (
      customFields.find((field) => field.title === "Impacted Service Area") ||
      {}
    ).value;

    if (serviceArea !== "Inbound API") {
      return storedIncidentType;
    }

    const orgTags =
      typeof HelpCenter !== "undefined" &&
      HelpCenter.user &&
      Array.isArray(HelpCenter.user.organizations) &&
      HelpCenter.user.organizations[0] &&
      Array.isArray(HelpCenter.user.organizations[0].tags)
        ? HelpCenter.user.organizations[0].tags
        : [];

    if (orgTags.includes("platform_voucherengine")) {
      console.warn(
        "[serviceIncidentMain] Incident Submission Status missing for Inbound API; derived VE from org tags"
      );
      return "Inbound API (VE) SI Logged";
    }

    if (orgTags.includes("platform_banking_live")) {
      console.warn(
        "[serviceIncidentMain] Incident Submission Status missing for Inbound API; derived BL from org tags"
      );
      return "Inbound API (BL) SI Logged";
    }

    console.warn(
      "[serviceIncidentMain] Incident Submission Status missing for Inbound API and no known org tag matched"
    );
    return storedIncidentType;
  };

  const incidentType = getResolvedIncidentType(fields);
  if (DEBUG_REQUIRE_ON_SUBMIT)
    console.log("[serviceIncidentMain] Incident Type detected:", incidentType);

  if (
    incidentType === undefined ||
    incidentType === null ||
    incidentType === "—"
  ) {
    console.error("Incident Type is undefined, aborting field injection !!!!");
    return;
  }
  hideUnwantedFields(incidentType);

  // 4. Get field configuration from FIELDS_BY_TYPE
  const selectedFields = FIELDS_BY_TYPE[incidentType] || FIELDS_BY_TYPE.default;

  if (!selectedFields.length) {
    return;
  }

  if (checkValueExist(selectedFields)) return;

  // const creationDate = new Date(
  //   JSON.parse(localStorage.getItem("request") || "{}").created_at
  // );
  // injectCountdownNotice("#request_submit_notice", creationDate);

  // 5. Build HTML for each field
  selectedFields.forEach((fieldConfig) => {
    const fieldHtml = buildField(fieldConfig);
    hideSelectedFieldByName(fieldConfig.name);
    html += fieldHtml;
  });

  // 6. Find or create container #zd-extra-fields
  let target = document.querySelector("#zd-extra-fields");
  if (!target) {
    if (DEBUG_REQUIRE_ON_SUBMIT)
      console.warn(
        "[serviceIncidentMain] Container #zd-extra-fields not found, creating it"
      );
    target = document.createElement("div");
    target.id = "zd-extra-fields";
    const ticketDetails = document.querySelector("#ticket-details");
    if (ticketDetails) {
      ticketDetails.appendChild(target);
    } else {
      console.error(
        "[serviceIncidentMain] Cannot find #ticket-details to append container"
      );
      document.body.appendChild(target); // fallback
    }
  }

  // 7. Inject HTML into container
  target.innerHTML = html;

  if (DEBUG_REQUIRE_ON_SUBMIT)
    console.log(
      "[serviceIncidentMain] ✅ Fields injected successfully for incident type:",
      incidentType
    );

  // Defer validation until after DOM rendering
  setTimeout(() => {
    requireOnSubmit(selectedFields);
  }, 0);

  const rerun = () => requireOnSubmit(selectedFields);
  const saveValues = (target) => {
    if (target && target.value === null) return;

    const fieldId = target.id;
    if (fieldId && fieldId.startsWith("request_custom_fields_")) {
      localStorage.setItem(fieldId, target.value);
    }
  };

  // Add listener for description field (works with CKEditor)
  const ckEditorDiv = document.querySelector(
    '[contenteditable="true"][role="textbox"]'
  );
  if (ckEditorDiv) {
    // CKEditor detection
    ckEditorDiv.addEventListener("input", rerun);
    ckEditorDiv.addEventListener("keyup", rerun);
    ckEditorDiv.addEventListener("blur", rerun);
    if (DEBUG_REQUIRE_ON_SUBMIT)
      console.log("[serviceIncidentMain] CKEditor listener added");
  } else {
    // Fallback for regular textarea
    const descriptionField = document.querySelector("#request_description");
    if (descriptionField) {
      descriptionField.addEventListener("input", rerun);
      descriptionField.addEventListener("change", rerun);
      if (DEBUG_REQUIRE_ON_SUBMIT)
        console.log("[serviceIncidentMain] Description field listener added");
    }
  }

  // Also poll CKEditor content every 500ms as backup
  const pollInterval = setInterval(() => {
    rerun();
  }, 500);

  document.addEventListener(
    "input",
    function (e) {
      saveValues(e.target);
      rerun();
    },
    true
  );

  document.addEventListener(
    "change",
    function (e) {
      saveValues(e.target);
      rerun();
    },
    true
  );

  const btn = document.querySelector(
    'input[type="submit"], button[type="submit"]'
  );
  if (btn) {
    btn.addEventListener("click", async function (e) {
      // e.preventDefault(); // stop the submit

      let customfields = [];
      selectedFields.forEach((fieldConfig) => {
        const zid = fieldConfig.zid;
        const fieldSelectorID = `request_custom_fields_${zid}`;
        const fieldValue = localStorage.getItem(fieldSelectorID);
        if (fieldValue) {
          customfields.push({ id: Number(zid), value: fieldValue });
        }
      });
      payload = { customFields: customfields };

      // Set flag to indicate fields were submitted to N8N
      localStorage.setItem("FieldsSent", "true");
      localStorage.setItem("FieldsSentTimestamp", Date.now().toString());

      if (DEBUG_REQUIRE_ON_SUBMIT)
        console.log("Submitting payload:", { customFields: customfields });
      // 10. Update ticket via API
      try {
        // const result = await N8N_UpdateTicket(ticketId, { priority: 'high', customFields: customfields });
        await N8N_UpdateTicket(ticketId, payload).then((result) => {
          console.log("API response:", result);
        });
      } catch (error) {
        console.error("Error updating ticket:", error);
      }
    });
  }
}
