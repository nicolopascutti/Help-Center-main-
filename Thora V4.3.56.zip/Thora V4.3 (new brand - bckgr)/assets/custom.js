// entry point
const SERVICE_INCIDENT_FORM_ID = "23677534458396";
const IMPACTED_SERVICE_AREA_SELECTOR = "request_custom_fields_23677332295196";

// =====================================================
//               INCIDENT CONFIGURATION
// =====================================================

const INCIDENT_CONFIG = {
  cards: [
    {
      id: "transaction",
      title: "Transaction Processing",
      desc: "Payment processing, authorizations, settlements",
      icon: "M20 4H4c-1.11 0-1.99.89-1.99 2L2 18c0 1.11.89 2 2 2h16c1.11 0 2-.89 2-2V6c0-1.11-.89-2-2-2m0 14H4v-6h16zm0-10H4V6h16z",
      serviceAreaValue: "service-area_transaction_processing",
    },
    {
      id: "inbound",
      title: "Inbound API",
      desc: "Integration endpoints, API connectivity",
      icon: "m14 12-2 2-2-2 2-2zm-2-6 2.12 2.12 2.5-2.5L12 1 7.38 5.62l2.5 2.5zm-6 6 2.12-2.12-2.5-2.5L1 12l4.62 4.62 2.5-2.5zm12 0-2.12 2.12 2.5 2.5L23 12l-4.62-4.62-2.5 2.5zm-6 6-2.12-2.12-2.5 2.5L12 23l4.62-4.62-2.5-2.5z",
      serviceAreaValue: "service-area_inbound_api",
    },
    {
      id: "reports",
      title: "Reports & Files",
      desc: "Scheduled reports, file generation",
      icon: "M14 2H6c-1.1 0-1.99.9-1.99 2L4 20c0 1.1.89 2 1.99 2H18c1.1 0 2-.9 2-2V8zm2 16H8v-2h8zm0-4H8v-2h8zm-3-5V3.5L18.5 9z",
      serviceAreaValue: "service-area_reports_and_files",
    },
    {
      id: "digitisation",
      title: "Digitisation",
      desc: "Digital wallet provisioning, tokenization",
      icon: "M14 9h-4c-.55 0-1 .45-1 1v4c0 .55.45 1 1 1h4c.55 0 1-.45 1-1v-4c0-.55-.45-1-1-1m-1 4h-2v-2h2zm8-3c0-.55-.45-1-1-1h-1V7c0-1.1-.9-2-2-2h-2V4c0-.55-.45-1-1-1s-1 .45-1 1v1h-2V4c0-.55-.45-1-1-1s-1 .45-1 1v1H7c-1.1 0-2 .9-2 2v2H4c-.55 0-1 .45-1 1s.45 1 1 1h1v2H4c-.55 0-1 .45-1 1s.45 1 1 1h1v2c0 1.1.9 2 2 2h2v1c0 .55.45 1 1 1s1-.45 1-1v-1h2v1c0 .55.45 1 1 1s1-.45 1-1v-1h2c1.1 0 2-.9 2-2v-2h1c.55 0 1-.45 1-1s-.45-1-1-1h-1v-2h1c.55 0 1-.45 1-1m-5 7H8c-.55 0-1-.45-1-1V8c0-.55.45-1 1-1h8c.55 0 1 .45 1 1v8c0 .55-.45 1-1 1",
      serviceAreaValue: "service-area_digitisation",
    },
    {
      id: "fraud",
      title: "Fraud",
      desc: "Fraud detection systems, rule engines",
      icon: "M12 1 3 5v6c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V5zm0 10.99h7c-.53 4.12-3.28 7.79-7 8.94V12H5V6.3l7-3.11z",
      redirectUrl: "/hc/en-us/requests/new?ticket_form_id=11811081570845",
    },
    /* {
      id: "product-module-field-test",
      title: "[TEST] Product / Module Field test",
      desc: "Test form for product or module field validation",
      icon: "M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2m0 16H5V5h14zm-8-3h2v2h-2zm0-10h2v8h-2z",
      redirectUrl: `/hc/en-us/requests/new?ticket_form_id=${PRODUCT_MODULE_FIELD_TEST_FORM_ID}`,
      visibleToOrganizationIds: PRODUCT_MODULE_FIELD_TEST_ALLOWED_ORG_IDS,
      visibleToOrganizationNames: PRODUCT_MODULE_FIELD_TEST_ALLOWED_ORG_NAMES,
    }, */
  ],

  severityPanels: {
    transaction: {
      title: "Transaction Processing",
      items: [
        {
          level: "P1",
          severity: "Critical",
          time: "within 15 minutes",
          desc: "Authorization requests are continually or intermittently failing (>30%)",
        },
        {
          level: "P2",
          severity: "High",
          time: "within 1 hour",
          desc: "Authorization requests are continually or intermittently failing (10%-30%)",
        },
        {
          level: "P3",
          severity: "Medium",
          time: "within 4 hours",
          desc: "Isolated cases / Small numbers of intermittent transaction failures (>10%)",
        },
        {
          level: "P4",
          severity: "Low",
          time: "within 1 business day",
          desc: "Single transaction failure",
        },
      ],
    },
    inbound: {
      title: "Inbound API",
      items: [
        {
          level: "P1",
          severity: "Critical",
          time: "within 15 minutes",
          desc: "Single / Multiple Core API's continually failing",
        },
        {
          level: "P2",
          severity: "High",
          time: "within 1 hour",
          desc: "Single / Multiple Core API's intermittently failing",
        },
        {
          level: "P3",
          severity: "Medium",
          time: "within 4 hours",
          desc: "Isolated cases / Small numbers of continual Non-Core API failures",
        },
        {
          level: "P4",
          severity: "Low",
          time: "within 1 business day",
          desc: "Isolated cases / Small numbers of intermittent Non-Core API failures",
        },
      ],
    },
    reports: {
      title: "Reports & Files",
      items: [
        {
          level: "P3",
          severity: "Medium",
          time: "within 4 hours",
          desc: "Delayed delivery of reports (i.e. Settlement, Perso files, etc)",
        },
      ],
    },
    digitisation: {
      title: "Digitisation",
      items: [
        {
          level: "P2",
          severity: "High",
          time: "within 1 hour",
          desc: "Provisioning / I-TSP: >10 min Full Downtime",
        },
        {
          level: "P3",
          severity: "Medium",
          time: "within 4 hours",
          desc: "Other Services (Push provisioning, Show card data, Customer service API): >10 min Full Downtime",
        },
        {
          level: "P4",
          severity: "Low",
          time: "within 1 business day",
          desc: "full DT or Any Partial Downtime",
        },
      ],
    },
  },

  // Field Config
  fields: {
    organization: {
      type: "select",
      id: "incident_organization",
      label: "Organization",
      required: true,
      className: "org-select-label",
      options: [],
    },
    subject: {
      type: "text",
      id: "incident_subject",
      label: "Subject",
      required: true,
    },
    product_module: {
      type: "select",
      id: "product_module",
      label: "Product / Module",
      required: true,
      options: [],
      description: "The Paymentology Platform or Product Module related to your request.",
    },
    transaction_ids: {
      type: "textarea",
      id: "transaction_ids",
      label: "Transaction ID(s)",
      required: true,
    },
    observed_start_time: {
      type: "text",
      id: "observed_start_time",
      label: "Observed Start Time (UTC)",
      required: true,
    },
    end_time: {
      type: "text",
      id: "end_time",
      label: "End Time (UTC)",
      required: true,
    },
    incident_impact: {
      type: "select",
      id: "incident_impact",
      label: "Transaction Impact",
      required: true,
      options: [
        { value: "txn-impact_more_than_30", label: ">30%" },
        { value: "txn-impact_between_30_10", label: "30-10%" },
        { value: "txn-impact_less_than_10", label: "<10%" },
        { value: "txn-impact_few_txn_impacted", label: "Few TXN impacted" },
        { value: "txn-impact_dont_know", label: "Don't know" },
      ],
    },
    affected_api: {
      type: "select",
      id: "affected_api",
      label: "Affected API",
      required: true,
      description: `
        <div class="incident-field-note note">
          <div class="incident-field-note__body">
            <strong>Core APIs:</strong><br>
            Create customer V2 (/pws/pws_create_customer/)<br>
            Create account V2 (/pws/pws_create_account/)<br>
            Create card V2 (/pws/pws_create_card/)<br>
            Create account V2 (additional accounts)<br>
            Link card and account V2 (/pws/pws_link_card_acc/)<br>
            Load balance V2 (/pws/pws_load_balance/)<br>
            Set default card account (/pws/pws_set_default_card_account/)<br><br>
            <strong>Other APIs:</strong><br>
            Any other method not included in the core APIs
          </div>
        </div>
      `,
      options: [
        { value: "core_apis_failing", label: "Core API" },
        { value: "core_apis_intermittent", label: "Other API" },
      ],
    },
    api_impact: {
      type: "select",
      id: "api_impact",
      label: "API Impact",
      required: true,
      options: [
        { value: "api_impact_complete_outage", label: "Complete outage" },
        {
          value: "api_impact_degraded_service",
          label: "Degraded service (intermittent failure)",
        },
        {
          value: "api_impact_limited_customer_impact",
          label: "Limited customer impact",
        },
        {
          value: "api_impact_single_customer",
          label: "Single customer (isolated case)",
        },
      ],
    },
    connection_issue: {
      type: "select",
      id: "connection_issue",
      label: "Connection Issue",
      required: true,
      options: [
        { value: "connection-issue_yes", label: "Yes" },
        { value: "connection-issue_no", label: "No" },
      ],
    },
    impacted_report: {
      type: "text",
      id: "impacted_report",
      label: "Impacted Report",
      required: true,
    },
    report_date_time: {
      type: "text",
      id: "report_date_time",
      label: "Report Date / Time (UTC)",
      required: true,
    },
    digitalisation_impact: {
      type: "select",
      id: "digitalisation_impact",
      label: "Digitalisation Impact",
      required: true,
      options: [
        { value: "digit-impact_all_attempts", label: "All Attempts" },
        { value: "digit-impact_partial_attempts", label: "Partial Attempts" },
        { value: "digit-impact_few_attempts", label: "Few Attempts" },
      ],
    },
    affected_scheme: {
      type: "multiselect",
      id: "affected_scheme_multiselect",
      label: "Affected Scheme",
      options: [
        { value: "scheme_visa", label: "Visa" },
        { value: "scheme_mastercard", label: "Mastercard" },
        { value: "scheme_other", label: "Other" },
      ],
    },
    digitalisation_services: {
      type: "multiselect",
      id: "digitalisation_service_multiselect",
      label: "Digitilisation Services Impacted",
      options: [
        {
          value: "digit-service-impact_tokenisation_i-tsp-issuer_wallet",
          label: "Tokenisation (I-TSP/Issuer wallet)",
        },
        {
          value: "digit-service-impact_push_provisioning",
          label: "Push provisioning",
        },
        { value: "digit-service-impact_other_service", label: "Other Service" },
      ],
    },
    affected_digitalisation_service: {
      type: "select",
      id: "affected_digitalisation_service",
      label: "Affected Digitalisation Service",
      required: true,
      options: [
        {
          value: "affected-digit_tokenisation_issuer_wallet",
          label: "Tokenisation / Issuer wallet",
        },
        {
          value: "affected-digit_impact_push_provisioning",
          label: "Push provisioning",
        },
        { value: "affected-digit_meacarddata", label: "MeaCardData" },
        { value: "affected-digit_token_lcm", label: "Token LCM" },
        { value: "affected-digit_measerviceportal", label: "MeaServicePortal" },
      ],
    },
    impacted_wallet: {
      type: "multiselect",
      id: "impacted_wallet_multiselect",
      label: "Impacted Wallet",
      options: [
        { value: "impacted-wallet_apple_pay", label: "Apple Pay" },
        { value: "impacted-wallet_google_pay", label: "Google Pay" },
        { value: "impacted-wallet_issuer_wallet", label: "Issuer Wallet" },
        { value: "impacted-wallet_click_to_pay", label: "Click to Pay" },
        { value: "impacted-wallet_ecommerce", label: "Ecommerce" },
        { value: "impacted-wallet_other_wallet", label: "Other" },
      ],
    },
    manual_provisioning_working: {
      type: "select",
      id: "manual_provisioning_working",
      label: "Manual Provisioning Working",
      required: true,
      options: [
        { value: "manual_provisioning_yes", label: "Yes" },
        { value: "manual_provisioning_no", label: "No" },
      ],
    },
  },

  // Fform config
  forms: {
    transaction: {
      fields: [
        "organization",
        "incident_impact",
        "affected_scheme",
        "transaction_ids",
        "observed_start_time",
        "product_module",
        "subject",
      ],
      buttonText: "Continue to Step 2",
    },
    inbound: {
      fields: ["organization", "affected_api", "api_impact", "product_module", "subject"],
      buttonText: "Submit Incident",
    },
    reports: {
      fields: [
        "organization",
        "impacted_report",
        "report_date_time",
        "connection_issue",
        "product_module",
        "subject",
      ],
      buttonText: "Submit Incident",
    },
    digitisation: {
      fields: [
        "organization",
        "affected_scheme",
        "digitalisation_services",
        "digitalisation_impact",
        "affected_digitalisation_service",
        "impacted_wallet",
        "observed_start_time",
        "manual_provisioning_working",
        "end_time",
        "product_module",
        "subject",
      ],
      buttonText: "Submit Incident",
    },
  },
};

// Field IDs for Zendesk
const FIELDS_DICT = {
  product_module: { id: 28175955127324 },
  incident_impact: { id: 23677306298524 },
  incident_scheme: { id: 23677211046556 },
  affected_api: { id: 23677272409372 },
  api_impact: { id: 26052682743708 },
  affected_scheme: { id: 23677211046556 },
  transaction_ids: { id: 23677215518876 },
  observed_start_time: { id: 23677132759580 },
  end_time: { id: 23677140564508 },
  connection_issue: { id: 23677089625372 },
  impacted_report: { id: 23677086187036 },
  report_date_time: { id: 23677070972956 },
  digitilisation_services_impacted: { id: 23677240208028 },
  digitalisation_impact: { id: 23677214406300 },
  affected_digitalisation_service: { id: 23677198854940 },
  impacted_wallet: { id: 23677121919132 },
  manual_provisioning_working: { id: 23676989810972 },
};

const SERVICE_AREA = {
  id: 23677332295196,
  "Transaction Processing": "service-area_transaction_processing",
  "Inbound API": "service-area_inbound_api",
  "Reports & Files": "service-area_reports_and_files",
  Digitisation: "service-area_digitisation",
};

const Manual_Provisioning_Working = {
  id: 23676989810972,
  Yes: "manual_provisioning_yes",
  No: "manual_provisioning_no",
};

// =====================================================
// FUNCTIONS FOR DYNAMIC GENERATION
// =====================================================

function generateCardHTML(cardConfig) {
  if (cardConfig.redirectUrl) {
    return `
      <button type="button" class="subsection-card subsection-card--incident" onclick="window.location.href='${cardConfig.redirectUrl}'">
        <span class="subsection-card-icon">
          <svg viewBox="0 0 24 24"><path d="${cardConfig.icon}"></path></svg>
        </span>
        <h3 class="subsection-card-title">${cardConfig.title}</h3>
        <p class="subsection-card-desc">${cardConfig.desc}</p>
      </button>
    `;
  }
  return `
    <button type="button" class="subsection-card subsection-card--incident" data-panel="${cardConfig.id}">
      <span class="subsection-card-icon">
        <svg viewBox="0 0 24 24"><path d="${cardConfig.icon}"></path></svg>
      </span>
      <h3 class="subsection-card-title">${cardConfig.title}</h3>
      <p class="subsection-card-desc">${cardConfig.desc}</p>
    </button>
  `;
}

function generateSeverityPanelHTML(panelId, panelConfig) {
  const itemsHTML = panelConfig.items
    .map(
      (item) => `
    <li>
      <span class="incident-panel-severity-${item.level.toLowerCase()}">${item.level}</span> <b>${item.severity}</b><br>
      Response time: <b>${item.time}</b><br><br> ${item.desc}
    </li>
  `
    )
    .join("");

  return `
    <div class="incident-panel incident-panel--hidden" id="panel-${panelId}">
      <h3 class="incident-panel-title">Severity Definitions - ${panelConfig.title}</h3>
      <ul class="incident-panel-severity">${itemsHTML}</ul>
    </div>
  `;
}

function generateFieldHTML(fieldKey, fieldConfig, uniqueSuffix = "") {
  const requiredMark = fieldConfig.required
    ? '<span style="color: #CC3340;">*</span>'
    : "";
  const uniqueId = fieldConfig.id + uniqueSuffix;
  const descriptionHTML = fieldConfig.description
    ? `<div class="incident-field-description">${fieldConfig.description}</div>`
    : "";

  if (fieldConfig.type === "select") {
    const optionsHTML = fieldConfig.options
      .map((opt) => `<option value="${opt.value}">${opt.label}</option>`)
      .join("");

    const className = fieldConfig.className
      ? ` class="${fieldConfig.className}"`
      : "";
    const style =
      fieldConfig.className === "org-select-label"
        ? ' style="display:block;"'
        : "";
    const requiredAttr = fieldConfig.required ? " required" : "";

    return `
      <label${className}${style}>${fieldConfig.label} ${requiredMark}
        <select id="${uniqueId}"${requiredAttr}>
          <option value="" selected disabled hidden>-</option>
          ${optionsHTML}
        </select>
        ${descriptionHTML}
      </label>
    `;
  }

  if (fieldConfig.type === "text") {
    const requiredAttr = fieldConfig.required ? " required" : "";
    return `
      <label>${fieldConfig.label} ${requiredMark}
        <input type="text" id="${uniqueId}"${requiredAttr}>
        ${descriptionHTML}
      </label>
    `;
  }

  if (fieldConfig.type === "textarea") {
    const requiredAttr = fieldConfig.required ? " required" : "";
    return `
      <label>${fieldConfig.label} ${requiredMark}
        <textarea id="${uniqueId}" rows="4"${requiredAttr}></textarea>
        ${descriptionHTML}
      </label>
    `;
  }

  if (fieldConfig.type === "multiselect") {
    const requiredAttr = fieldConfig.required ? ' data-required="true"' : "";
    const optionsHTML = fieldConfig.options
      .map(
        (opt) => `
      <div class="custom-multiselect-option">
        <input type="checkbox" id="${opt.value}${uniqueSuffix}" value="${opt.value}">
        <label for="${opt.value}${uniqueSuffix}">${opt.label}</label>
      </div>
    `
      )
      .join("");

    return `
      <div class="custom-multiselect-container">
        <div class="custom-multiselect-label">${fieldConfig.label}</div>
        <div class="custom-multiselect" id="${uniqueId}"${requiredAttr}>
          <div class="custom-multiselect-toggle" tabindex="0">
            <div class="custom-multiselect-selected"></div>
            <span class="custom-multiselect-arrow"></span>
          </div>
          <div class="custom-multiselect-dropdown">
            ${optionsHTML}
          </div>
        </div>
      </div>
    `;
  }

  return "";
}

function generateFormHTML(formType) {
  const formConfig = INCIDENT_CONFIG.forms[formType];
  if (!formConfig) return "";

  const uniqueSuffix = "_" + formType;
  const fieldsHTML = formConfig.fields
    .map((fieldKey) => {
      const fieldConfig = INCIDENT_CONFIG.fields[fieldKey];
      return generateFieldHTML(fieldKey, fieldConfig, uniqueSuffix);
    })
    .join("");

  return `
    <form class="incident-panel-form" id="incident-form">
      ${fieldsHTML}
      <div class="incident-form-btn-wrapper">
        <button type="button" class="submit-btn submit-incident-button--active">${formConfig.buttonText}</button>
      </div>
    </form>
  `;
}

function getCurrentUserOrganizationIds() {
  if (Array.isArray(window.userOrganizations)) {
    const ids = window.userOrganizations
      .map((org) => String(org.id))
      .filter(Boolean);
    if (ids.length) {
      return ids;
    }
  }

  if (
    typeof HelpCenter === "undefined" ||
    !HelpCenter.user ||
    !Array.isArray(HelpCenter.user.organizations)
  ) {
    return [];
  }

  return HelpCenter.user.organizations
    .map((org) => String(org.id))
    .filter(Boolean);
}

function getCurrentUserOrganizationNames() {
  if (Array.isArray(window.userOrganizations)) {
    const names = window.userOrganizations
      .map((org) => String(org.name || "").trim())
      .filter(Boolean);
    if (names.length) {
      return names;
    }
  }

  if (
    typeof HelpCenter === "undefined" ||
    !HelpCenter.user ||
    !Array.isArray(HelpCenter.user.organizations)
  ) {
    return [];
  }

  return HelpCenter.user.organizations
    .map((org) => String(org.name || "").trim())
    .filter(Boolean);
}

function productModuleLabel(value) {
  const knownLabels = {
    voucherengine: "Voucher Engine",
    paycredit: "PayCredit",
    lume: "LUME",
  };
  const key = String(value).replace(/^prod_module_/, "").toLowerCase();
  if (knownLabels[key]) return knownLabels[key];

  return String(value)
    .replace(/^prod_module_/, "")
    .replace(/[_-]+/g, " ")
    .replace(/\b\w/g, (letter) => letter.toUpperCase());
}

// Organization tags use the org_prod_module_* namespace, while the
// Zendesk ticket field continues to use prod_module_* values.
function normalizeProductModuleTag(value) {
  const tag = String(value || "").trim();
  if (tag.startsWith("org_prod_module_")) {
    return tag.replace(/^org_/, "");
  }
  return tag;
}

function populateProductModuleOptions(formContainer, organizations) {
  const select = formContainer?.querySelector('[id^="product_module"]');
  if (!select) return;

  const values = (organizations || [])
    .flatMap((org) => {
      const fieldValues = [
        org.organization_fields?.["28096102665628"],
        org.organization_fields?.["product___module__2_"],
        org.fields?.["28096102665628"],
        org.fields?.["product___module__2_"],
        org.custom_fields?.["28096102665628"],
        org.custom_fields?.["product___module__2_"],
      ].flatMap((value) => Array.isArray(value) ? value : String(value || "").split(","));
      const tagValues = Array.isArray(org.tags) ? org.tags : [];
      return [...fieldValues, ...tagValues];
    })
    .map(normalizeProductModuleTag)
    .filter((tag) => tag.startsWith("prod_module_"));
  const uniqueValues = [...new Set(values)];

  select.innerHTML = '<option value="" selected disabled hidden>-</option>';
  uniqueValues.forEach((value) => {
    const option = document.createElement("option");
    option.value = value;
    option.textContent = productModuleLabel(value);
    select.appendChild(option);
  });

  if (uniqueValues.length === 1) {
    select.value = uniqueValues[0];
  }
}

async function populateProductModuleOptionsFromOrganizationDetails(formContainer, organizations) {
  const detailedOrganizations = await Promise.all((organizations || []).map(async (org) => {
    if (Array.isArray(org.tags) && org.tags.length) return org;
    try {
      const response = await fetch(`/api/v2/organizations/${encodeURIComponent(org.id)}.json`);
      if (!response.ok) return org;
      const payload = await response.json();
      return payload.organization || org;
    } catch (error) {
      console.warn("Unable to load organization product/module tags", error);
      return org;
    }
  }));
  populateProductModuleOptions(formContainer, detailedOrganizations);
  return detailedOrganizations;
}

/* function canAccessProductModuleFieldTest() {
  const userOrgIds = getCurrentUserOrganizationIds();
  const userOrgNames = getCurrentUserOrganizationNames();

  return (
    PRODUCT_MODULE_FIELD_TEST_ALLOWED_ORG_IDS.some((allowedOrgId) =>
      userOrgIds.includes(String(allowedOrgId))
    ) ||
    PRODUCT_MODULE_FIELD_TEST_ALLOWED_ORG_NAMES.some((allowedOrgName) =>
      userOrgNames.includes(String(allowedOrgName))
    )
  );
} */

function renderIncidentCards() {
  const container = document.getElementById("incident-cards-container");
  if (!container) return;

  const formSlot = container.querySelector("#incident-form-slot");
  const userOrgIds = getCurrentUserOrganizationIds();
  const userOrgNames = getCurrentUserOrganizationNames();

  const cardsHTML = INCIDENT_CONFIG.cards
    .filter((card) => {
      const matchesOrgId = Array.isArray(card.visibleToOrganizationIds)
        ? card.visibleToOrganizationIds.some((orgId) =>
            userOrgIds.includes(String(orgId))
          )
        : false;

      const matchesOrgName = Array.isArray(card.visibleToOrganizationNames)
        ? card.visibleToOrganizationNames.some((orgName) =>
            userOrgNames.includes(String(orgName))
          )
        : false;

      if (
        Array.isArray(card.visibleToOrganizationIds) ||
        Array.isArray(card.visibleToOrganizationNames)
      ) {
        return matchesOrgId || matchesOrgName;
      }

      return true;
    })
    .map((card) => generateCardHTML(card))
    .join("");

  if (formSlot) {
    formSlot.insertAdjacentHTML("beforebegin", cardsHTML);
  } else {
    container.innerHTML = cardsHTML + '<div id="incident-form-slot"></div>';
  }
}

function renderSeverityPanels() {
  const sidebar = document.getElementById("incidentSidebar");
  if (!sidebar) return;

  let panelsHTML = "";
  for (const [panelId, panelConfig] of Object.entries(
    INCIDENT_CONFIG.severityPanels
  )) {
    panelsHTML += generateSeverityPanelHTML(panelId, panelConfig);
  }
  sidebar.innerHTML = panelsHTML;
}

// =====================================================
// The rest of the custom code
// =====================================================

function hideTicketFormSelector() {
  if (!document.getElementById("hide-ticket-form-style")) {
    const style = document.createElement("style");
    style.id = "hide-ticket-form-style";
    style.textContent =
      ".request_ticket_form_id{display:none!important}" +
      ".request_ticket_form_id .nesty-input{display:none!important}" +
      "#request_issue_type_select{display:none!important}";
    document.head.appendChild(style);
  }
}
// redirect https://help.paymentology.com/hc/en-us/requests/new to /p/submit_request
function redirectBareNewRequestPage() {
  const match = window.location.pathname.match(
    /^\/hc\/([^/]+)\/requests\/new\/?$/
  );
  if (!match) return;

  const params = new URLSearchParams(window.location.search);
  if (params.has("ticket_form_id")) return; // if a ticket form is selected, dont' redirect

  const locale = match[1];
  window.location.replace(`/hc/${locale}/p/submit_request`);
}

redirectBareNewRequestPage();
// Check if we're on the form page and there was a submission error
if (/\/hc\/[^/]+\/requests\/new/.test(location.pathname)) {
  const params = new URLSearchParams(location.search);
  // hide the ticket form selector
  if (params.has("ticket_form_id")) {
    hideTicketFormSelector();
  }
  const hasError = sessionStorage.getItem("zd_submission_error");

  if (hasError === "true") {
    // Clear the flag
    sessionStorage.removeItem("zd_submission_error");

    // Show error notification after a short delay to ensure page is loaded
    setTimeout(() => {
      showErrorNotification(
        "The ticket could not be submitted. Please review the values below and try again."
      );
    }, 500);
  }
}

//custom page
if (/\/hc\/[^/]+\/p\/production_service_incident/.test(location.pathname)) {
  console.log("Production Service Incident page loaded");

  // This page is now standalone, so we must bind the incident UI directly.
  document.addEventListener("DOMContentLoaded", function () {
    // Generăm cardurile și panourile dinamic
    renderIncidentCards();
    renderSeverityPanels();
    // Apoi inițializăm logica
    initIncidentPanelScript();
  });

  document.addEventListener("click", (e) => {
    const button = e.target.closest("button.submit-btn");
    if (!button) return;

    e.preventDefault();
    if (button.dataset.formValid !== "true") {
      showErrorNotification("Please complete all required fields before continuing.");
      return;
    }

    const activeCard = document.getElementsByClassName(
      "incident-card--active"
    )[0];
    const actualVal = activeCard ? activeCard.innerText.split("\n")[0] : "";

    // Obținem tipul formularului din form container
    const formContainer = document.getElementById("incident-form-slot");
    const formType = formContainer?.dataset.kind || "";
    const selectedCardConfig = INCIDENT_CONFIG.cards.find(
      (card) => card.id === formType
    );
    const serviceAreaValue = selectedCardConfig?.serviceAreaValue || "";
    const serviceAreaLabel = selectedCardConfig?.title || actualVal;

    // Căutăm câmpurile folosind selectori mai flexibili
    const subjectField = formContainer?.querySelector(
      '[id^="incident_subject"]'
    );
    const subject = subjectField?.value || "";
    const productModuleField = formContainer?.querySelector(
      '[id^="product_module"]'
    );
    const productModule = productModuleField?.value || "";

    let url = `/hc/en-us/requests/new?ticket_form_id=${SERVICE_INCIDENT_FORM_ID}&tf_subject=${encodeURIComponent(subject)}&tf_${FIELDS_DICT["product_module"].id}=${encodeURIComponent(productModule)}&tf_description=${encodeURIComponent(serviceAreaLabel)}&tf_${SERVICE_AREA["id"]}=${encodeURIComponent(serviceAreaValue)}`;

    const orgSelect = formContainer?.querySelector(
      '[id^="incident_organization"]'
    );
    const organizationId = orgSelect?.value || "";
    if (organizationId) {
      url += `&tf_organization_id=${encodeURIComponent(organizationId)}`;
    }

    if (formType === "transaction") {
      const impactSelect = formContainer?.querySelector(
        '[id^="incident_impact"]'
      );
      const incidentImpact = impactSelect?.value || "";
      const transactionIdsField = formContainer?.querySelector(
        '[id^="transaction_ids"]'
      );
      const transactionIds = transactionIdsField?.value || "";
      const observedStartField = formContainer?.querySelector(
        '[id^="observed_start_time"]'
      );
      const observedStartTime = observedStartField?.value || "";
      const schemeMultiselect = formContainer?.querySelector(
        '[id^="affected_scheme_multiselect"]'
      );
      const selectedSchemes = schemeMultiselect
        ? getMultiSelectValues(schemeMultiselect)
        : [];
      const incidentScheme = selectedSchemes.join(",");
      url += `&tf_${FIELDS_DICT["incident_impact"].id}=${encodeURIComponent(incidentImpact)}&tf_${FIELDS_DICT["incident_scheme"].id}=${encodeURIComponent(incidentScheme)}&tf_${FIELDS_DICT["observed_start_time"].id}=${encodeURIComponent(observedStartTime)}`;
    } else if (formType === "inbound") {
      const affectedApiSelect = formContainer?.querySelector(
        '[id^="affected_api"]'
      );
      const inboundAffectedApi = affectedApiSelect?.value || "";
      url += `&tf_${FIELDS_DICT["affected_api"].id}=${encodeURIComponent(inboundAffectedApi)}`;

      const apiImpactSelect =
        formContainer?.querySelector('[id^="api_impact"]');
      const inboundApiImpact = apiImpactSelect?.value || "";
      url += `&tf_${FIELDS_DICT["api_impact"].id}=${encodeURIComponent(inboundApiImpact)}`;
    } else if (formType === "reports") {
      const impactedReportField = formContainer?.querySelector(
        '[id^="impacted_report"]'
      );
      const impactedReport = impactedReportField?.value || "";
      const reportDateTimeField = formContainer?.querySelector(
        '[id^="report_date_time"]'
      );
      const reportDateTime = reportDateTimeField?.value || "";
      const connectionIssueSelect = formContainer?.querySelector(
        '[id^="connection_issue"]'
      );
      const connectionIssue = connectionIssueSelect?.value || "";
      url += `&tf_${FIELDS_DICT["impacted_report"].id}=${encodeURIComponent(impactedReport)}&tf_${FIELDS_DICT["report_date_time"].id}=${encodeURIComponent(reportDateTime)}&tf_${FIELDS_DICT["connection_issue"].id}=${encodeURIComponent(connectionIssue)}`;
    } else if (formType === "digitisation") {
      const digitImpactSelect = formContainer?.querySelector(
        '[id^="digitalisation_impact"]'
      );
      const digitalisationImpact = digitImpactSelect?.value || "";
      const affectedDigitalisationServiceSelect = formContainer?.querySelector(
        '[id^="affected_digitalisation_service"]'
      );
      const affectedDigitalisationService =
        affectedDigitalisationServiceSelect?.value || "";
      const impactedWalletMultiselect = formContainer?.querySelector(
        '[id^="impacted_wallet_multiselect"]'
      );
      const selectedImpactedWallets = impactedWalletMultiselect
        ? getMultiSelectValues(impactedWalletMultiselect)
        : [];
      const impactedWallet = selectedImpactedWallets.join(",");
      const observedStartField = formContainer?.querySelector(
        '[id^="observed_start_time"]'
      );
      const observedStartTime = observedStartField?.value || "";
      const manualProvisioningSelect = formContainer?.querySelector(
        '[id^="manual_provisioning_working"]'
      );
      const manualProvisioningWorking =
        manualProvisioningSelect?.value || "";
      const endTimeField = formContainer?.querySelector('[id^="end_time"]');
      const endTime = endTimeField?.value || "";
      const schemeMultiselect = formContainer?.querySelector(
        '[id^="affected_scheme_multiselect"]'
      );
      const selectedSchemes = schemeMultiselect
        ? getMultiSelectValues(schemeMultiselect)
        : [];
      const incidentScheme = selectedSchemes.join(",");
      const digitilisationMultiselect = formContainer?.querySelector(
        '[id^="digitalisation_service_multiselect"]'
      );
      const selectedDigitilisationServices = digitilisationMultiselect
        ? getMultiSelectValues(digitilisationMultiselect)
        : [];
      const digitisationServices = selectedDigitilisationServices.join(",");
      url += `&tf_${FIELDS_DICT["digitalisation_impact"].id}=${encodeURIComponent(digitalisationImpact)}&tf_${FIELDS_DICT["incident_scheme"].id}=${encodeURIComponent(incidentScheme)}&tf_${FIELDS_DICT["digitilisation_services_impacted"].id}=${encodeURIComponent(digitisationServices)}&tf_${FIELDS_DICT["affected_digitalisation_service"].id}=${encodeURIComponent(affectedDigitalisationService)}&tf_${FIELDS_DICT["impacted_wallet"].id}=${encodeURIComponent(impactedWallet)}&tf_${FIELDS_DICT["observed_start_time"].id}=${encodeURIComponent(observedStartTime)}&tf_${FIELDS_DICT["manual_provisioning_working"].id}=${encodeURIComponent(manualProvisioningWorking)}&tf_${FIELDS_DICT["end_time"].id}=${encodeURIComponent(endTime)}`;
    } else {
      console.warn("Unknown incident type selected:", formType, actualVal);
      showErrorNotification("The selected incident type could not be resolved. Please reselect the incident and try again.");
      return;
    }

    console.log("Submitting incident with URL:", url);
    showLoadingOverlay(true);
    const transactionIdsField = formContainer?.querySelector(
      '[id^="transaction_ids"]'
    );
    const transactionIdsPayload = transactionIdsField
      ? { transactionIds: transactionIdsField.value }
      : null;
    stealthSubmit(url, transactionIdsPayload);
  });
}

// --- [INCIDENT SUB-SECTION LOGIC] ---
function initIncidentPanelScript() {
  const sidebar = document.getElementById("incidentSidebar");
  const cardsPanel = document.querySelector(
    "#incident-section .incident-cards"
  );
  if (!cardsPanel) return;

  let formContainer = cardsPanel?.querySelector("#incident-form-slot");
  if (!formContainer && cardsPanel) {
    formContainer = document.createElement("div");
    formContainer.id = "incident-form-slot";
    formContainer.style.width = "100%";
    formContainer.style.marginTop = "16px";
    cardsPanel.appendChild(formContainer);
  }

  if (sidebar) {
    sidebar.style.display = "none";
    sidebar.querySelectorAll(".incident-panel").forEach((panel) => {
      panel.classList.add("incident-panel--hidden");
    });
  }
  if (formContainer) formContainer.replaceChildren();

  document
    .querySelectorAll("#incident-section .subsection-card[data-panel]")
    .forEach((card) => {
      card.onclick = function () {
        const label = card
          .querySelector(".subsection-card-title")
          .textContent.trim();
        const key = card.dataset.panel; // 'transaction' | 'inbound' | 'reports' | 'digitisation'

        // Generăm formularul dinamic din configurație
        formContainer.innerHTML = generateFormHTML(key);
        formContainer.classList.remove("incident-form--hidden");
        formContainer.dataset.kind = key;

        const today = new Date().toLocaleDateString("en-GB", {
          day: "2-digit",
          month: "long",
          year: "numeric",
        });
        const customerName =
          typeof HelpCenter !== "undefined" &&
          HelpCenter.user &&
          Array.isArray(HelpCenter.user.organizations) &&
          HelpCenter.user.organizations[0]
            ? HelpCenter.user.organizations[0].name
            : "";

        // Prefill subject field
        const subjectField = formContainer.querySelector(
          '[id^="incident_subject"]'
        );
        if (subjectField) {
          subjectField.value = `${label} Service Incident [${today}] [${customerName}]`;
        }

        // Populate and show organization dropdown if user has multiple orgs
        const orgSelect = formContainer.querySelector(
          '[id^="incident_organization"]'
        );
        const orgLabel = formContainer.querySelector(".org-select-label");
        const orgs =
          typeof HelpCenter !== "undefined" &&
          HelpCenter.user &&
          Array.isArray(HelpCenter.user.organizations)
            ? HelpCenter.user.organizations
            : [];

        if (typeof HelpCenter === "undefined" || !HelpCenter.user) {
          console.warn("HelpCenter object not available");
        }

        console.log(
          "orgSelect:",
          orgSelect,
          "orgLabel:",
          orgLabel,
          "orgs:",
          orgs
        );
        if (orgSelect && orgs.length > 1) {
          orgSelect.innerHTML =
            '<option value="" selected disabled hidden>-</option>';
          orgs.forEach((org) => {
            const option = document.createElement("option");
            option.value = org.id;
            option.textContent = org.name;
            orgSelect.appendChild(option);
          });
          if (orgLabel) orgLabel.style.display = "block";
          orgSelect.required = true;
        } else {
          if (orgLabel) orgLabel.style.display = "none";
          if (orgSelect) orgSelect.required = false;
        }

        populateProductModuleOptionsFromOrganizationDetails(formContainer, orgs);
        if (orgSelect) {
          orgSelect.addEventListener("change", () => {
            const selectedOrg = orgs.find((org) => String(org.id) === String(orgSelect.value));
            populateProductModuleOptionsFromOrganizationDetails(formContainer, selectedOrg ? [selectedOrg] : orgs);
          });
        }

        const cardsPanelEl = document.getElementsByClassName("incident-cards");
        cardsPanelEl[0].classList.add("incident-cards--active");

        document
          .querySelectorAll("#incident-section .subsection-card")
          .forEach((c) => {
            c.classList.remove("incident-card--active");
          });
        card.classList.add("incident-card--active");

        if (sidebar) {
          sidebar.style.display = "block";
          sidebar.querySelectorAll(".incident-panel").forEach((panel) => {
            panel.classList.add("incident-panel--hidden");
          });
          const panelId = "panel-" + card.getAttribute("data-panel");
          const panel = document.getElementById(panelId);
          if (panel) panel.classList.remove("incident-panel--hidden");
        }

        // Initialize any multi-selects in the injected form
        formContainer
          .querySelectorAll(".custom-multiselect")
          .forEach(function (ms) {
            initCustomMultiSelect(ms);
          });

        // Setup form validation
        setupIncidentFormValidation(formContainer);
      };
    });
}

// Validate incident form and enable/disable submit button
function setupIncidentFormValidation(formContainer) {
  const submitBtn = formContainer.querySelector(".submit-btn");
  if (!submitBtn) return;

  // Keep the button clickable so validation can surface a visible message.
  submitBtn.disabled = false;
  submitBtn.style.opacity = "0.5";
  submitBtn.style.cursor = "pointer";
  submitBtn.dataset.formValid = "false";

  function validateForm() {
    let isValid = true;

    // Check all required dropdowns
    const dropdowns = formContainer.querySelectorAll("select[required]");
    dropdowns.forEach(function (dropdown) {
      if (!dropdown.value || dropdown.value === "") {
        isValid = false;
      }
    });

    // Check all multi-selects (if they exist and have at least one selection)
    const multiSelects = formContainer.querySelectorAll(
      '.custom-multiselect[data-required="true"]'
    );
    multiSelects.forEach(function (ms) {
      const values = getMultiSelectValues(ms);
      if (values.length === 0) {
        isValid = false;
      }
    });

    const requiredTextFields = formContainer.querySelectorAll(
      'input[type="text"][required], textarea[required]'
    );
    requiredTextFields.forEach(function (field) {
      if (!field.value || field.value.trim() === "") {
        isValid = false;
      }
    });

    // Check subject field (always required)
    const subjectField = formContainer.querySelector('[id^="incident_subject"]');
    if (
      subjectField &&
      (!subjectField.value || subjectField.value.trim() === "")
    ) {
      isValid = false;
    }

    // Enable/disable submit button
    if (isValid) {
      submitBtn.style.opacity = "1";
      submitBtn.style.cursor = "pointer";
      submitBtn.dataset.formValid = "true";
    } else {
      submitBtn.style.opacity = "0.5";
      submitBtn.style.cursor = "pointer";
      submitBtn.dataset.formValid = "false";
    }

    return isValid;
  }

  // Add event listeners to all form inputs
  const dropdowns = formContainer.querySelectorAll("select");
  dropdowns.forEach(function (dropdown) {
    dropdown.addEventListener("change", validateForm);
  });

  const textInputs = formContainer.querySelectorAll(
    'input[type="text"], textarea'
  );
  textInputs.forEach(function (input) {
    input.addEventListener("input", validateForm);
  });

  // Add listeners to multi-select checkboxes
  const multiSelectCheckboxes = formContainer.querySelectorAll(
    '.custom-multiselect input[type="checkbox"]'
  );
  multiSelectCheckboxes.forEach(function (checkbox) {
    checkbox.addEventListener("change", validateForm);
  });

  // Initial validation
  validateForm();
}

// =====================================================
// DEPRECATED / UNUSED FUNCTIONS
// These functions are kept for reference but are no longer called.
// They were used for the old multi-section navigation system.
// =====================================================

/*
function resetServiceSection() {
  const section = document.getElementById('service-section');
  if (!section) return;
  const root = section.querySelector('[data-service-root]');
  const rootElements = section.querySelectorAll('[data-service-root-element]');
  const subs = section.querySelectorAll('[data-service-sub]');
  if (root) root.style.display = '';
  rootElements.forEach(el => {
    el.style.display = '';
  });
  subs.forEach(sub => {
    sub.style.display = 'none';
  });
}

function initServiceSection() {
  const section = document.getElementById('service-section');
  if (!section || section.dataset.boundService === 'true') return;
  section.dataset.boundService = 'true';

  const root = section.querySelector('[data-service-root]');
  const rootElements = section.querySelectorAll('[data-service-root-element]');
  const subs = section.querySelectorAll('[data-service-sub]');

  section.addEventListener('click', function (e) {
    const trigger = e.target.closest('[data-service-target]');
    if (trigger) {
      e.preventDefault();
      const key = trigger.dataset.serviceTarget;
      if (!key || !root) return;
      rootElements.forEach(el => {
        el.style.display = 'none';
      });
      root.style.display = 'none';
      subs.forEach(sub => {
        sub.style.display = sub.dataset.serviceSub === key ? '' : 'none';
      });
      return;
    }

    const back = e.target.closest('[data-service-back]');
    if (back) {
      e.preventDefault();
      if (root) root.style.display = '';
      rootElements.forEach(el => {
        el.style.display = '';
      });
      subs.forEach(sub => {
        sub.style.display = 'none';
      });
    }
  });
}
*/

/*
function resetFraudSection() {
  const section = document.getElementById('fraud-section');
  if (!section) return;
  const root = section.querySelector('[data-fraud-root]');
  const rootElements = section.querySelectorAll('[data-fraud-root-element]');
  const subs = section.querySelectorAll('[data-fraud-sub]');
  if (root) root.style.display = '';
  rootElements.forEach(el => {
    el.style.display = '';
  });
  subs.forEach(sub => {
    sub.style.display = 'none';
  });
}

function initFraudSection() {
  const section = document.getElementById('fraud-section');
  if (!section || section.dataset.boundFraud === 'true') return;
  section.dataset.boundFraud = 'true';

  const root = section.querySelector('[data-fraud-root]');
  const rootElements = section.querySelectorAll('[data-fraud-root-element]');
  const subs = section.querySelectorAll('[data-fraud-sub]');

  section.addEventListener('click', function (e) {
    const trigger = e.target.closest('[data-fraud-target]');
    if (trigger) {
      e.preventDefault();
      const key = trigger.dataset.fraudTarget;
      if (!key || !root) return;
      rootElements.forEach(el => {
        el.style.display = 'none';
      });
      root.style.display = 'none';
      subs.forEach(sub => {
        sub.style.display = sub.dataset.fraudSub === key ? '' : 'none';
      });
      return;
    }

    const back = e.target.closest('[data-fraud-back]');
    if (back) {
      e.preventDefault();
      if (root) root.style.display = '';
      rootElements.forEach(el => {
        el.style.display = '';
      });
      subs.forEach(sub => {
        sub.style.display = 'none';
      });
    }
  });
}
*/

function stealthSubmit(url, transactionIdsPayload = null) {
  // iframe stealth submit
  const ifr = document.createElement("iframe");
  ifr.id = "zd-stealth";
  ifr.style.cssText =
    "position:fixed;left:-9999px;top:-9999px;width:1px;height:1px;opacity:0;pointer-events:none;";
  document.body.appendChild(ifr);

  let loadCount = 0;
  let submitAttempted = false;

  let watchdog = setTimeout(() => {
    // Watchdog triggered - submission failed, redirect with error flag
    sessionStorage.setItem("zd_submission_error", "true");
    window.location.href = url;
  }, 20000); // 20s watchdog

  ifr.addEventListener("load", async () => {
    try {
      const w = ifr.contentWindow;
      const d = ifr.contentDocument;
      if (!w || !d) return;

      loadCount++;

      // Check if we successfully created a ticket
      if (
        /\/requests\/\d+/.test(w.location.pathname) ||
        d.querySelector(".request-details")
      ) {
        clearTimeout(watchdog);
        showLoadingOverlay(false);
        const ticketMatch = w.location.pathname.match(/\/requests\/(\d+)/);
        const productModuleValue = new URL(url, window.location.origin)
          .searchParams.get(`tf_${FIELDS_DICT.product_module.id}`) || "";

        if (transactionIdsPayload) {
          const productionIncidentPayload = {
            ticketId: ticketMatch ? ticketMatch[1] : null,
            transactionIds: transactionIdsPayload.transactionIds,
          };
          window.productionIncidentPayload = productionIncidentPayload;
          try {
            // n8n workflow: Handle long TIDs field submissions
            // https://n8n.pty.tools/workflow/nhTclgZflv9S5CVn
            const n8nResponse = await fetch(
              "https://n8n.pty.tools/webhook/f12e9c9e-83a6-4c7d-ac4f-5c168f3ccdee",
              {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(productionIncidentPayload),
              }
            );
            if (!n8nResponse.ok) {
              console.warn("n8n returned an error:", n8nResponse.status);
            }
          } catch (error) {
            console.warn("Unable to send production incident payload to n8n:", error);
          }
        }

        window.location.href = w.location.href;
        return;
      }

      // Check for error messages in the form (validation errors)
      if (submitAttempted && loadCount > 1) {
        const hasErrors = d.querySelector(
          '.notification-error, .form-field.has-error, .flash-error, [role="alert"]'
        );
        if (hasErrors) {
          clearTimeout(watchdog);
          // Redirect to form page with error flag
          sessionStorage.setItem("zd_submission_error", "true");
          window.location.href = url;
          return;
        }
      }

      // First load - try to submit
      const btn = d.querySelector(
        'input[type="submit"][name="commit"], button[type="submit"]'
      );
      if (btn && !submitAttempted) {
        const requestedProductModule = new URL(url, window.location.origin)
          .searchParams.get(`tf_${FIELDS_DICT.product_module.id}`);
  if (requestedProductModule) {
          const productModuleField =
            d.getElementById(`request_custom_fields_${FIELDS_DICT.product_module.id}`) ||
            d.querySelector(`[name="request[custom_fields][${FIELDS_DICT.product_module.id}]"]`);
          if (productModuleField) {
            productModuleField.value = requestedProductModule;
            productModuleField.dispatchEvent(new Event("change", { bubbles: true }));
          }
        }
        submitAttempted = true;
        const jitter = 900 + Math.floor(Math.random() * 600); // 900–1800ms
        setTimeout(() => {
          btn.click();
        }, jitter);
      }
    } catch (e) {
      // Cross-origin or other error
      console.warn("Stealth submit error:", e);
    }
  });

  ifr.src = url;
}

function showLoadingOverlay(show) {
  const id = "zd-loading-overlay";
  let el = document.getElementById(id);
  if (show) {
    if (!el) {
      el = document.createElement("div");
      el.id = id;
      el.setAttribute("aria-busy", "true");
      el.style.cssText =
        "position:fixed;inset:0;z-index:2147483647;background:rgba(255,255,255,.95);display:flex;align-items:center;justify-content:center;font:500 16px/1.4 system-ui,Segoe UI,Roboto,Arial;";
      el.innerHTML = `
        <div style="display:flex;flex-direction:column;align-items:center;gap:14px;">
          <div style="width:48px;height:48px;border-radius:50%;border:4px solid #e5e7eb;border-top-color:#1f3b8a;animation:zdspin 1s linear infinite;"></div>
          <div>Submitting incident…</div>
        </div>
        <style>@keyframes zdspin{to{transform:rotate(360deg)}}</style>
      `;
      document.body.appendChild(el);
    }
  } else {
    el && el.remove();
  }
}

function showErrorNotification(message) {
  const id = "zd-error-notification";

  // Remove any existing notification
  const existing = document.getElementById(id);
  if (existing) existing.remove();

  const notification = document.createElement("div");
  notification.id = id;
  notification.setAttribute("role", "alert");
  notification.style.cssText = `
    position: fixed;
    top: 20px;
    right: 20px;
    z-index: 2147483647;
    min-width: 300px;
    max-width: 500px;
    background: #fff;
    border: 1px solid #d8dcde;
    border-radius: 4px;
    padding: 16px;
    box-shadow: 0 4px 12px rgba(0,0,0,0.15);
    display: flex;
    align-items: flex-start;
    gap: 12px;
    font-family: system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Arial, sans-serif;
    animation: slideIn 0.3s ease-out;
  `;

  notification.innerHTML = `
    <svg width="20" height="20" viewBox="0 0 20 20" style="flex-shrink: 0; margin-top: 2px;">
      <circle cx="10" cy="10" r="9" fill="#CC3340"/>
      <path d="M10 5.5v5m0 2.5v1" stroke="#fff" stroke-width="1.5" stroke-linecap="round"/>
    </svg>
    <div style="flex: 1; font-size: 14px; color: #2f3941; line-height: 1.5;">
      ${message}
    </div>
    <button type="button" onclick="this.parentElement.remove()" style="
      background: none;
      border: none;
      cursor: pointer;
      padding: 0;
      margin: 0;
      color: #68737d;
      font-size: 20px;
      line-height: 1;
      flex-shrink: 0;
      width: 20px;
      height: 20px;
      display: flex;
      align-items: center;
      justify-content: center;
    ">×</button>
    <style>
      @keyframes slideIn {
        from {
          transform: translateX(100%);
          opacity: 0;
        }
        to {
          transform: translateX(0);
          opacity: 1;
        }
      }
    </style>
  `;

  document.body.appendChild(notification);

  // Auto-remove after 8 seconds
  setTimeout(() => {
    if (notification.parentElement) {
      notification.style.animation = "slideIn 0.3s ease-out reverse";
      setTimeout(() => notification.remove(), 300);
    }
  }, 8000);
}

// --- [GLOBAL BACK BUTTON LOGIC] ---
// DEPRECATED: This function was used for multi-section navigation
/*
function goBackToMainSection() {
  // Ascunde toate subsecțiunile mari
  document.querySelectorAll('.subsection-container[data-dynamic]').forEach(function (sec) {
    sec.style.display = 'none';
  });
  // Ascunde orice sub-subsecțiune activă
  document.querySelectorAll('.service-subsection, .fraud-subsection').forEach(function (sub) {
    sub.style.display = 'none';
  });
  // Afișează secțiunea principală și elementele ei
  document.querySelector('.custom-intake-section').style.display = 'block';
  document.querySelector('.custom-intake-grid').style.display = '';
  document.querySelector('.custom-intake-title').style.display = '';
  document.querySelector('.custom-intake-lead').style.display = '';
}
*/

// --- [CUSTOM MULTI-SELECT LOGIC] ---
function initCustomMultiSelect(container) {
  const toggle = container.querySelector(".custom-multiselect-toggle");
  const dropdown = container.querySelector(".custom-multiselect-dropdown");
  const selectedContainer = container.querySelector(
    ".custom-multiselect-selected"
  );
  const placeholder = container.querySelector(
    ".custom-multiselect-placeholder"
  );
  const checkboxes = container.querySelectorAll(
    '.custom-multiselect-option input[type="checkbox"]'
  );

  // Toggle dropdown
  toggle.addEventListener("click", function (e) {
    e.stopPropagation();
    container.classList.toggle("is-open");
  });

  // Close dropdown when clicking outside
  document.addEventListener("click", function (e) {
    if (!container.contains(e.target)) {
      container.classList.remove("is-open");
    }
  });

  // Update selected chips
  function updateSelected() {
    selectedContainer.innerHTML = "";
    let hasSelected = false;

    checkboxes.forEach(function (checkbox) {
      if (checkbox.checked) {
        hasSelected = true;
        const label = checkbox.parentElement
          .querySelector("label")
          .textContent.trim();
        const chip = document.createElement("div");
        chip.className = "custom-multiselect-chip";
        chip.innerHTML = `
          <span>${label}</span>
          <button type="button" class="custom-multiselect-chip-remove" data-value="${checkbox.value}">×</button>
        `;

        // Remove chip on click
        chip
          .querySelector(".custom-multiselect-chip-remove")
          .addEventListener("click", function (e) {
            e.stopPropagation();
            checkbox.checked = false;
            updateSelected();
          });

        selectedContainer.appendChild(chip);
      }
    });

    // Show/hide placeholder
    if (placeholder) placeholder.style.display = hasSelected ? "none" : "";
  }

  // Listen to checkbox changes
  checkboxes.forEach(function (checkbox) {
    checkbox.addEventListener("change", updateSelected);
  });

  // Initialize
  updateSelected();
}

// Get selected values from multi-select
function getMultiSelectValues(container) {
  const checkboxes = container.querySelectorAll(
    '.custom-multiselect-option input[type="checkbox"]:checked'
  );
  return Array.from(checkboxes).map((cb) => cb.value);
}

// Auto-init all multi-selects on page load
document.addEventListener("DOMContentLoaded", function () {
  document
    .querySelectorAll(".custom-multiselect")
    .forEach(function (container) {
      initCustomMultiSelect(container);
    });

  // Apply card visibility rules based on organization tags
  applyCardVisibilityRules();
});
// --- [END CUSTOM MULTI-SELECT LOGIC] ---

// --- [CARD VISIBILITY RULES BASED ON ORGANIZATION TAGS] ---
function applyCardVisibilityRules() {
  // Check if HelpCenter object exists
  if (typeof HelpCenter === "undefined" || !HelpCenter.user) {
    console.warn("HelpCenter object not available");
    return;
  }

  const user = HelpCenter.user;
  const userOrganizations = user.organizations || [];

  // Collect all organization tags and names
  const allOrgTags = new Set();
  const allOrgNames = new Set();
  const allOrgIds = new Set();

  userOrganizations.forEach(function (org) {
    if (org.id) {
      allOrgIds.add(String(org.id));
    }
    if (org.tags) {
      org.tags.forEach(function (tag) {
        allOrgTags.add(tag);
      });
    }
    if (org.name) {
      allOrgNames.add(org.name);
    }
  });

  // Convert to arrays for easier checking
  const orgTags = Array.from(allOrgTags);
  const orgNames = Array.from(allOrgNames);
  const orgIds = Array.from(allOrgIds);

  // console.log('User organizations:', orgNames);
  // console.log('Organization tags:', orgTags);

  // Special case: Paymentology can see everything
  const isPaymentology = orgNames.includes("Paymentology");

  if (isPaymentology) {
    console.log("Paymentology user - all cards visible");
    return; // Don't hide anything
  }

  // --- MAIN CATEGORY CARDS ---

  // DISPUTES: Customers with either cb_processing-yes or product_sprint
  // Keep temporary org exceptions until organisation tagging is fully in place.
  const canAccessDisputes =
    orgTags.includes("cb_processing-yes") ||
    orgTags.includes("product_sprint") ||
    orgNames.includes("Mama Money");

  if (!canAccessDisputes) {
    hideCard(
      "a.custom-intake-card--disputes",
      "Disputes (requires cb_processing-yes, product_sprint, or a temporary org exception)"
    );
  }

  // PROGRAMME MANAGEMENT: Acorn Platform and Voucher Engine customers only
  if (
    !orgTags.includes("platform_acorn") &&
    !orgTags.includes("platform_voucherengine")
  ) {
    hideCard(
      "a.custom-intake-card--programme-management",
      "Programme Management (requires platform_acorn or platform_voucherengine tag)"
    );
  }

  // --- DISPUTES SUBCATEGORY CARDS ---

  // CARD TRANSACTION DISPUTE V2: Not available for Acorn Platform customers
  if (orgTags.includes("platform_acorn")) {
    hideSubcategoryCard(
      "#disputes-section",
      "Card Transaction Dispute v2",
      "Card Transaction Dispute v2 (not available for platform_acorn tag)"
    );
  }

  // --- SERVICE REQUEST SUBCATEGORY CARDS ---

  // CHANGE REQUEST: Processing customers only
  if (!orgTags.includes("product_sprint")) {
    hideSubcategoryCard(
      "#service-section",
      "Change Request",
      "Change Request (requires product_sprint tag)"
    );
  }

  // ATM Claim - Bank Zero: Acorn Platform customers only
  if (!orgTags.includes("platform_acorn")) {
    hideSubcategoryCard(
      "#service-section",
      "ATM Claim - Bank Zero",
      "ATM Claim - Bank Zero (requires platform_acorn tag)"
    );
  }

  // CAMPAIGN CHANGE REQUEST: Voucher Engine customers only
  if (!orgTags.includes("platform_voucherengine")) {
    hideSubcategoryCard(
      "#service-section",
      "Campaign Change Request",
      "Campaign Change Request (requires platform_voucherengine tag)"
    );
  }

  // --- FRAUD SUBCATEGORY CARDS ---

  // FRAUD INCIDENT: Not available for Acorn Platform customers
  if (orgTags.includes("platform_acorn")) {
    hideSubcategoryCard(
      "#fraud-section",
      "Fraud Incident",
      "Fraud Incident (not available for platform_acorn tag)"
    );
  }

  // MERCHANT BLOCK REQUEST: Available for all customers (no restrictions)
  // Card is always visible unless user is Acorn platform
  if (orgTags.includes("platform_acorn")) {
    hideSubcategoryCard(
      "#fraud-section",
      "Merchant Block Request",
      "Merchant Block Request (not available for platform_acorn tag)"
    );
  }

  // TOKEN > PAN CONVERSION: Banking.Live customers only
  if (!orgTags.includes("platform_banking_live")) {
    hideSubcategoryCard(
      "#fraud-section",
      "Token > PAN Conversion",
      "Token > PAN (requires platform_banking_live tag)"
    );
  }

  // TRACKING NUMBER > PAN CONVERSION: Sprint customers only (Voucher Engine)
  if (!orgTags.includes("platform_voucherengine")) {
    hideSubcategoryCard(
      "#fraud-section",
      "Tracking # > PAN Conversion",
      "Tracking # > PAN (requires platform_voucherengine tag)"
    );
  }

  // AMEND / DELETE FRAUD RULE: Banking.Live customers only, Not available for Acorn Platform
  if (
    !orgTags.includes("platform_banking_live") ||
    orgTags.includes("platform_acorn")
  ) {
    hideSubcategoryCard(
      "#fraud-section",
      "Amend / Delete Fraud Rule",
      "Amend/Delete Fraud Rule (requires platform_banking_live tag, not available for platform_acorn)"
    );
  }

  // NEW REQUEST FRAUD RULE: Banking.Live customers only, Not available for Acorn Platform
  if (
    !orgTags.includes("platform_banking_live") ||
    orgTags.includes("platform_acorn")
  ) {
    hideSubcategoryCard(
      "#fraud-section",
      "Request new Fraud Rule",
      "New Fraud Rule (requires platform_banking_live tag, not available for platform_acorn)"
    );
  }

  // MC FRAUD REPORTING: Specific organisations only (Ascend Group / Albo)
  const allowedMCFraudOrgs = ["Ascend Group (True Money)", "Albo"];
  const hasMCFraudAccess = orgNames.some(function (name) {
    return allowedMCFraudOrgs.includes(name);
  });

  if (!hasMCFraudAccess) {
    hideSubcategoryCard(
      "#fraud-section",
      "Mastercard Fraud Reporting Form",
      "MC Fraud Reporting (requires specific org)"
    );
  }

  // FLEXPAY FRAUD CLAIM: Acorn Platform customers only
  if (!orgTags.includes("platform_acorn")) {
    hideSubcategoryCard(
      "#fraud-section",
      "Fraud Claim - Bank Zero",
      "Fraud Claim - Bank Zero (requires platform_acorn tag)"
    );
  }

  // --- PROGRAMME MANAGEMENT SUBCATEGORY CARDS ---

  // EXCESS FUND TRANSFER: Acorn Platform customers only
  if (!orgTags.includes("platform_acorn")) {
    hideSubcategoryCard(
      "#programme-management-section",
      "Excess Fund Transfer",
      "Excess Fund Transfer (requires platform_acorn tag)"
    );
  }

  // FICA TRANSFER: Acorn Platform customers only
  if (!orgTags.includes("platform_acorn")) {
    hideSubcategoryCard(
      "#programme-management-section",
      "FICA Transfer",
      "FICA Transfer (requires platform_acorn tag)"
    );
  }

  // Create or Update a Cardholder: Acorn Platform customers only
  if (!orgTags.includes("platform_acorn")) {
    hideSubcategoryCard(
      "#programme-management-section",
      "Create or Update a Cardholder",
      "Create or Update a Cardholder (requires platform_acorn tag)"
    );
  }

  // Card Order Request: Acorn Platform customers only
  if (!orgTags.includes("platform_acorn")) {
    hideSubcategoryCard(
      "#programme-management-section",
      "Card Order Request",
      "Card Order Request (requires platform_acorn tag)"
    );
  }

  // Remove Negative Tracker: Acorn Platform customers only
  if (!orgTags.includes("platform_acorn")) {
    hideSubcategoryCard(
      "#programme-management-section",
      "Remove Negative Tracker",
      "Remove Negative Tracker (requires platform_acorn tag)"
    );
  }

  // Activate/Deactivate Account or Card: Acorn Platform customers only
  if (!orgTags.includes("platform_acorn")) {
    hideSubcategoryCard(
      "#programme-management-section",
      "Activate/Deactivate Account or Card",
      "Activate/Deactivate Account or Card (requires platform_acorn tag)"
    );
  }

  // Missing Payment: Acorn Platform customers only
  if (!orgTags.includes("platform_acorn")) {
    hideSubcategoryCard(
      "#programme-management-section",
      "Missing Payment",
      "Missing Payment (requires platform_acorn tag)"
    );
  }

  // Missing Airtime/Electricity/Data Token: Acorn Platform customers only
  if (!orgTags.includes("platform_acorn")) {
    hideSubcategoryCard(
      "#programme-management-section",
      "Missing Airtime/Electricity/Data Token",
      "Missing Airtime/Electricity/Data Token (requires platform_acorn tag)"
    );
  }

  // Manual Load: Voucher Engine customers and Paymentology org 360237360057 only
  if (
    !orgTags.includes("platform_voucherengine") &&
    !orgIds.includes("360237360057")
  ) {
    hideSubcategoryCard(
      "#programme-management-section",
      "Manual Load",
      "Manual Load (requires platform_voucherengine tag or org id 360237360057)"
    );
  }
}

function hideCard(selector, reason) {
  const card = document.querySelector(selector);
  if (card) {
    card.style.display = "none";
    console.log("Hidden card:", reason);
  }
}

function hideSubcategoryCard(sectionSelector, titleText, reason) {
  const section = document.querySelector(sectionSelector);
  if (!section) return;

  const cards = section.querySelectorAll(".subsection-card-title");
  cards.forEach(function (titleElement) {
    const cardTitle = titleElement.textContent.trim();
    const searchTitle = titleText.trim();

    if (cardTitle === searchTitle) {
      const card = titleElement.closest(".subsection-card, button, a");
      if (card) {
        card.style.display = "none";
        console.log("Hidden subcategory card:", reason);
      }
    }
  });
}
// --- [END CARD VISIBILITY RULES] ---
