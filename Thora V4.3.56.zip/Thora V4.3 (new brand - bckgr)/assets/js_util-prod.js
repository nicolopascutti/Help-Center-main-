function display_form_hint() {
  const params = new URLSearchParams(window.location.search);
  const formId = params.get("ticket_form_id");
  // console.log(window.location.search);

  if (!formId) {
    return;
  }

  const calloutElements = {
    hint: document.getElementById("form-hint"),
    warning: document.getElementById("form-warning"),
    danger: document.getElementById("form-danger"),
    note: document.getElementById("form-note"),
  };

  Object.values(calloutElements).forEach((element) => {
    if (!element) {
      return;
    }
    element.classList.add("hidden");
    element.style.display = "";
    element.innerHTML = "";
  });

  const noteObject =
    '<em class="fa-solid fa-credit-card callout--note--icon"></em><div class="callout-body"><p>It is strictly prohibited to provide <strong>Full Card Numbers (PANs)</strong> on tickets.</p><p>Please redact or mask any sensitive card data before submitting.</p></div>';

  const formCallouts = {
    9252769581341: {
      hint: '<p><em class="fa-solid fa-circle-info callout--info--icon">&nbsp;</em></p><div class="callout-body"><p>Use this form to request assistance related to a paycard or voucher, such as:</p><ul><li>Card to Card transfer</li><li>Report a lost or faulty report</li><li>Check a card balance</li></ul><p></p></div>',
      note: noteObject,
    },
    9252182331037: {
      hint: '<p><em class="fa-solid fa-circle-info callout--info--icon">&nbsp;</em></p><div class="callout-body"><p>Please ensure that you provide as much information as possible so that we can help you faster:</p><ul class="form-hint-ul"><li>Details on the issues you are seeing</li><li>Logs for failed API call</li><li>Screenshots of errors you are seeing</li>        </ul><p>For more information, please see the following Help Centre article on how to log a Service Incident: <a href="https://support.paymentology.com/hc/en-us/articles/9228664274333" target="_blank" rel="noopener noreferrer">How to log a Service Incident</a></p></div>',
      danger:
        '<p><em class="fa-solid fa-bolt callout--danger--icon">&nbsp;</em></p><div class="callout-body"><p>This form <strong>should be used</strong> to log issues relating to Transactions.</p></div>',
      note: noteObject,
    },
    10126232762781: {
      hint: '<p><em class="fa-solid fa-circle-info callout--info--icon">&nbsp;</em></p><div class="callout-body"><p>Before logging your request, please see the following article which details how to log a dispute and what documents are required: <a href="https://support.paymentology.com/hc/en-us/articles/10133662089245">How to dispute a card transaction (chargeback) </a></p></div>',
      warning:
        '<p><em class="fa-solid fa-triangle-exclamation callout--warning--icon">&nbsp;</em></p><div class="callout-body"><p>When submitting a dispute with <b>more than 5 transactions</b>, complete and attach the following document to your request: <ul class="form-hint-ul"><li><em class="fa-solid fa-link" style="color:#61A5FF;">&nbsp;&nbsp;</em><a href="/hc/en-us/article_attachments/13302295181724" target="_blank" class="attachment-meta-item meta-data" title="Download">Transaction-list.xlsx</a></li></ul></p><p>Please note that this does not replace the dispute forms that are still required to submit with chargebacks.</p><p>Before submitting a Card Transaction Dispute relating to fraud, it is mandatory to <b>stop the card</b>.</p></div>',
      danger:
        '<p><em class="fa-solid fa-bolt callout--danger--icon">&nbsp;</em></p><div class="callout-body"><p>Please note that this form will be officially deprecated on <strong>18th August 2025</strong>.</p><p>Please use the new <a href="/hc/en-us/requests/new?ticket_form_id=20029681614364" target="_blank">Dispute Form</a> going forward.</p></div>',
      note: noteObject,
    },
    9252814736029: {
      hint: '<p><em class="fa-solid fa-circle-info callout--info--icon">&nbsp;</em></p><div class="callout-body"><p>Please provide as much detail as possible in relation to your product queries, as this will help us answer your question as quickly as possible:</p><ul><li>API / Error codes</li><li>Logs</li></ul><p></p></div>',
      note: noteObject,
    },
    9252743303837: {
      hint: '<p><em class="fa-solid fa-circle-info callout--info--icon">&nbsp;</em></p><div class="callout-body"><p>Using this form you can <b>request access</b> to a different Paymentology service:</p><ul class="form-hint-ul"><li>PayControl (for <em>Banking.Live</em>)</li><li>Support Portal</li></ul><p>Please provide the email(s) for users requiring access.</p></div></div>',
      note: noteObject,
    },
    11811109144989: {
      hint: '<p><em class="fa-solid fa-circle-info callout--info--icon">&nbsp;</em></p><div class="callout-body"><p>Before logging your request, see the following article: <a href="https://help.paymentology.com/hc/en-us/articles/28705822560028-Amend-Delete-a-Fraud-Rule-FAQs" target="_blank" rel="noopener noreferrer">Amend / Delete a Fraud Rule FAQs</a></p><p>Requesting Fraud Rule changes is only available on the <strong>Banking.Live</strong> platform.</p></div>',
      note: noteObject,
    },
    11811207026589: {
      hint: '<p><em class="fa-solid fa-circle-info callout--info--icon">&nbsp;</em></p><div class="callout-body"><p>Before logging your request, see the following article: <a href="https://support.paymentology.com/hc/en-us/articles/11836380641821-Request-a-new-Fraud-Rule-FAQs" target="_blank" rel="noopener noreferrer">Request a new Fraud Rule FAQs</a></p><p>Requesting Fraud Rule changes is only available on the <strong>Banking.Live</strong> platform.</p><p><strong>Note: </strong>Complex rule development may result in additional costs - if you have questions about rule development, please reach out to your Account Manager.</p></div>',
      note: noteObject,
    },
    11811081570845: {
      hint: '<p><em class="fa-solid fa-circle-info callout--info--icon">&nbsp;</em></p><div class="callout-body"><p>Before logging your request, see the following article: <a href="https://support.paymentology.com/hc/en-us/articles/11836476141597-Reporting-an-incident-of-Fraud-FAQs" target="_blank" rel="noopener noreferrer">Reporting an incident of Fraud FAQs</a></p></div>',
      danger:
        '<p><em class="fa-solid fa-bolt callout--danger--icon">&nbsp;</em></p><div class="callout-body"><p>This form should not be used to <strong>dispute a card transaction / log a chargeback</strong>. To submit a chargeback, use the following Ticket Form: <a href="https://help.paymentology.com/hc/en-us/requests/new?ticket_form_id=20029681614364" target="_blank">Dispute a Card Transaction</a></p></div>',
      note: noteObject,
    },
    10054527307292: {
      hint: '<p><em class="fa-solid fa-circle-info callout--info--icon">&nbsp;</em></p><div class="callout-body"><p>Use this form when you want to update a Fraud Rule to block a Merchant.</p></div>',
      note: noteObject,
    },
    5385513123357: {
      warning:
        '<p><em class="fa-solid fa-triangle-exclamation callout--warning--icon">&nbsp;</em></p><div class="callout-body"><p>This form should not be used to <strong>dispute a card transaction / log a chargeback</strong>. To submit a chargeback, use the following Ticket Form: <a href="https://support.paymentology.com/hc/en-us/requests/new?ticket_form_id=10126232762781" target="_blank">Dispute a Card Transaction</a></p></div>',
      danger:
        '<p><em class="fa-solid fa-bolt callout--danger--icon">&nbsp;</em></p><div class="callout-body"><p>To report issues affecting service performance or transaction processing, use the following Ticket Form: <a href="https://support.paymentology.com/hc/en-us/requests/new?ticket_form_id=9252182331037" target="_blank">Report a Service Incident</a></p></div>',
      note: noteObject,
    },
    15215216284572: {
      hint: '<p><em class="fa-solid fa-circle-info callout--info--icon">&nbsp;</em></p><div class="callout-body"><p>Use this form when a business need arises to have a full PAN available. For example:</p><ul class="form-hint-ul"><li>Doing fraud reporting to your network scheme</li><li>Internal fraud investigations</li></ul></p></div>',
      warning:
        '<p><em class="fa-solid fa-triangle-exclamation callout--warning--icon">&nbsp;</em></p><div class="callout-body"><p><ul><li> The data (PANs with associated identifier) will be shared via a SharePoint link. The client will have temporary access to this file.</li><li>We will thus require a business email address of the recipient who will receive this file.</li><li>Once the file is downloaded, please inform Paymentology and we will deactivate the link.</li><li>Ensure that all files with PANs are properly deleted as soon as possible.</li></ul></p></div>',
      note: noteObject,
    },
    15215270503196: {
      hint: '<p><em class="fa-solid fa-circle-info callout--info--icon">&nbsp;</em></p><div class="callout-body"><p>Use this form when a business need arises to have a full PAN available. For example:</p><ul class="form-hint-ul"><li>Doing fraud reporting to your network scheme</li><li>Internal fraud investigations</li></ul></p></div>',
      warning:
        '<p><em class="fa-solid fa-triangle-exclamation callout--warning--icon">&nbsp;</em></p><div class="callout-body"><p><ul><li> The data (PANs with associated identifier) will be shared via a SharePoint link. The client will have temporary access to this file.</li><li>We will thus require a business email address of the recipient who will receive this file.</li><li>Once the file is downloaded, please inform Paymentology and we will deactivate the link.</li><li>Ensure that all files with PANs are properly deleted as soon as possible.</li></ul></p></div>',
      note: noteObject,
    },
    13775208908444: {
      hint: '<p><em class="fa-solid fa-circle-info callout--info--icon">&nbsp;</em></p><div class="callout-body"><p>This form is used to request a migration of a Cardholder from a FICA Light Account to a Fica Full Account.</p><p>Based on the cardholder status, the following documentation is <strong>required</strong>:<ul><li>South African ID or Passport</li><li>Work Permit</li></ul></p></div>',
      warning:
        '<p><em class="fa-solid fa-triangle-exclamation callout--warning--icon">&nbsp;</em></p><div class="callout-body"><p>Failure to include copies of the required documentation will result in delays on processing your request.</p></div>',
      note: noteObject,
    },
    13778338328732: {
      hint: '<p><em class="fa-solid fa-circle-info callout--info--icon">&nbsp;</em></p><div class="callout-body"><p>This form is used to request a transfer of funds on a FICA Light Account to another nominated account.</p><p>To facilitate this request, the following document should be completed and attached when logging a request:<ul><li><em class="fa-solid fa-link" style="color:#61A5FF;">&nbsp;&nbsp;</em><a href="/hc/en-us/article_attachments/13779537770524" target="_blank" class="attachment-meta-item meta-data" title="Download">FICA Lite - FlexPay - EFT form.pdf</a></li></ul></p></div>',
      warning:
        '<p><em class="fa-solid fa-triangle-exclamation callout--warning--icon">&nbsp;</em></p><div class="callout-body"><p>Failure to include a completed copy of the ETF form will result in delays on processing your request.</p></div>',
      note: noteObject,
    },
    16257750048796: {
      hint: '<p><em class="fa-solid fa-circle-info callout--info--icon">&nbsp;</em></p><div class="callout-body"><p>All fields are mandatory for fraud reporting to the MasterCard Fraud and Loss Database.</p><p>Please ensure that data is accurate.</p><p>If reporting multiple transactions, the following document needs to be completed and attached to your requester: <ul><li><em class="fa-solid fa-link" style="color:#61A5FF;">&nbsp;&nbsp;</em><a href="/hc/en-us/article_attachments/16260473148828" target="_blank" class="attachment-meta-item meta-data" title="Download">Fraud Reporting_Bulk Template.xlsx</a></li></ul></p></div>',
      note: noteObject,
    },
    20029681614364: {
      hint: '<p><em class="fa-solid fa-circle-info callout--info--icon">&nbsp;</em></p><div class="callout-body"><p>Before logging your request, please see the following article which details how to log a dispute and what documents are required: <a href="https://support.paymentology.com/hc/en-us/articles/10133662089245">How to dispute a card transaction (chargeback) </a></p><p>When submitting a dispute with <b>more than 5 transactions</b>, complete and attach the following document to your request: <ul class="form-hint-ul"><li><em class="fa-solid fa-link" style="color:#61A5FF;">&nbsp;&nbsp;</em><a href="/hc/en-us/article_attachments/13302295181724" target="_blank" class="attachment-meta-item meta-data" title="Download">Transaction-list.xlsx</a></li></ul></p><p>Please note that this does not replace the dispute forms that are still required to submit with chargebacks.</p></div>',
      warning:
        '<p><em class="fa-solid fa-flask callout--warning--icon">&nbsp;</em></p><div class="callout-body"><p>This is a our Dispute Smart Form. When completing the form, include a valid Tracking Number / Wallet ID, Transaction ID and Transaction Date. The Merchant Name, Transaction Amount and Transaction Status will be automatically populated.<ul><li>If the Transaction Status is <strong>SETTLED</strong>, the transaction can be disputed and this request will be directed to our Chargebacks & Disputes team.</li><li>If the Transaction Status is <strong>PENDING</strong>, the transaction cannot be disputed yet. It should be rechecked in 10 days - if you submit this request, it will be directed to our Support team and you will receive an update in 10 - 11 days with the status of the transaction.</li><li>If no transaction data is populated on the form, you will need to manually populate the data and this request will be directed to our Support team for triage. If no transaction details are populated, it may be due to:<ul><li>No transaction information was found in our system.</li><li>Settlement with no associated or valid authorization</li></ul></li></ul></p></div>',
      note: noteObject,
    },
    22474332817052: {
      hint: '<p><em class="fa-solid fa-circle-info callout--info--icon">&nbsp;</em></p><div class="callout-body"><p>Use this form if the cardholder did not make or recognize the transaction, or if the card was lost, stolen, or retained.</p><p>If you are disputing more than four transactions, please include a CSV file with the transaction data — including dates, times, descriptions, and amounts of the disputed transactions — or provide a copy of the statement, clearly marking all disputed transactions.</p></div>',
      warning:
        '<p><em class="fa-solid callout--warning--icon">&nbsp;</em></p><div class="callout-body"><p>Do not include full card numbers in your request. Only include the last 4 digits of the card.</p></div>',
      note: noteObject,
    },
    22474020081052: {
      hint: '<p><em class="fa-solid fa-circle-info callout--info--icon">&nbsp;</em></p><div class="callout-body"><p>Use this form if the cardholder attempted a transaction but did not receive the funds, even though the amount was debited from the account.</p></div>',
      warning:
        '<p><em class="fa-solid callout--warning--icon">&nbsp;</em></p><div class="callout-body"><p>Do not include full card numbers in your request. Only include the last 4 digits of the card.</p></div>',
      note: noteObject,
    },
    26939464480796: {
      note: '<p><em class="fa-solid fa-circle-info callout--note--icon">&nbsp;</em></p><div class="callout-body"><p><strong>Required documentation by cardholder status</strong></p><ul><li><strong>Disbursement:</strong> Asylum Seeker Document or Refugee Permit</li><li><strong>Wallet:</strong> Foreign Passport (non-sanctioned countries). No work permit required.</li><li><strong>FICA light:</strong> Foreign Passport (non-sanctioned countries), South African ID, Asylum Seeker Document, or Refugee Permit. No proof of address or work permit required.</li><li><strong>Full FICA:</strong> Foreign Passport and Work Permit, or South African ID. No proof of address required.</li></ul></div>',
      warning:
        '<p><em class="fa-solid fa-triangle-exclamation callout--warning--icon">&nbsp;</em></p><div class="callout-body"><p>Failure to include copies of the required documentation will result in delays on processing your request.</p></div>',
    },
    29796154894748: {
      note: '<em class="fa-solid fa-circle-info callout--note--icon"></em><div class="callout-body"><p>The specified contact details will be used for the delivery.</p></div>',
    },
    26939986818972: {
      note: noteObject,
    },
    26994830585372: {
      note: noteObject,
    },
    26995027162652: {
      warning:
        '<p><em class="fa-solid fa-triangle-exclamation callout--warning--icon">&nbsp;</em></p><div class="callout-body"><p>Failure to include copies of the required documentation will result in delays on processing your request.</p></div>',
      note: noteObject,
    },
    26995056699932: {
      note: noteObject,
    },
    28643669349660: {
      hint: '<p><em class="fa-solid fa-circle-info callout--info--icon">&nbsp;</em></p><div class="callout-body"><p>To facilitate this request, please attach the following supporting documents when submitting your request:</p><ul><li>Proof of Payment</li><li><em class="fa-solid fa-link" style="color:#61A5FF;">&nbsp;&nbsp;</em><a href="https://help.paymentology.com/hc/en-us/article_attachments/28699625430172" target="_blank" class="attachment-meta-item meta-data" title="Download">Manual Load Indemnity Form</a></li></ul></p></div>',
      warning:
        '<p><em class="fa-solid fa-triangle-exclamation callout--warning--icon">&nbsp;</em></p><div class="callout-body"><p>Failure to include the Proof of Payment and completed indemnity form will result in delays on processing your request.</p></div>',
      note: noteObject,
    },
  };

  const calloutsForForm = formCallouts[formId];
  if (!calloutsForForm) {
    return;
  }

  Object.entries(calloutsForForm).forEach(([type, content]) => {
    const element = calloutElements[type];
    if (!element) {
      return;
    }
    element.classList.remove("hidden");
    element.style.display = "flex";
    element.innerHTML = content;
  });

  // Note callout already handled via formCallouts mapping above
}
