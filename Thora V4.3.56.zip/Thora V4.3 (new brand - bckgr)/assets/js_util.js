function display_form_hint() {
	const params = new URLSearchParams(window.location.search);
	const formId = params.get('ticket_form_id');
	
	if (!formId) {
		return;
	}

	const calloutElements = {
		note: document.getElementById('form-note'),
		hint: document.getElementById('form-hint'),
		warning: document.getElementById('form-warning'),
		danger: document.getElementById('form-danger')
	};

	Object.values(calloutElements).forEach((element) => {
		if (!element) {
			return;
		}
		element.classList.add('hidden');
		element.style.display = '';
		element.innerHTML = '';
	});

	const noteObject = '<p><em class="fa-solid fa-credit-card callout--note--icon">&nbsp;</em></p><div class="callout-body"><p><strong>Note:</strong> It is strictly prohibited to provide <strong>Full Card Numbers (PANs)</strong> on tickets.</p><p>Please redact or mask any sensitive card data before submitting.</p></div>';


	const formCallouts = {
		'9082664052509': {
			hint: '<p><em class="fa-solid fa-circle-info callout--info--icon">&nbsp;</em></p><div class="callout-body"><p>Use this form to request assistance related to a paycard or voucher, such as:</p><ul><li>Card to Card transfer</li><li>Report a lost or faulty report</li><li>Check a card balance</li></ul><p></p></div>',
			note: noteObject
		},
		'9062471887901': {
			hint: '<p><em class="fa-solid fa-circle-info callout--info--icon">&nbsp;</em></p><div class="callout-body"><p>Please ensure that you provide as much information as possible so that we can help you faster:</p><ul class="form-hint-ul"><li>Details on the issues you are seeing</li><li>Logs for failed API call</li><li>Screenshots of errors you are seeing</li></ul><p>For more information, please see the following Help Centre article on how to log a Service Incident: <a href="https://support.paymentology.com/hc/en-us/articles/9228664274333" target="_blank" rel="noopener noreferrer">How to log a Service Incident</a></p></div>',
			danger: '<p><em class="fa-solid fa-bolt callout--danger--icon">&nbsp;</em></p><div class="callout-body"><p>This form <strong>should be used</strong> to log issues relating to Transactions.</p></div>',
			note: noteObject
		},
		'8237593396509': {
			hint: '<p><em class="fa-solid fa-circle-info callout--info--icon">&nbsp;</em></p><div class="callout-body"><p>Please ensure that you provide as much information as possible so that we can help you faster:</p><ul class="form-hint-ul"><li>Details on the issues you are seeing</li><li>Logs for failed API call</li><li>Screenshots of errors you are seeing</li></ul><p>For more information, please see the following Help Centre article on how to log a Service Incident [BL]: <a href="https://www.google.com">How to log a Service Incident</a></p></div>',
			danger: '<p><em class="fa-solid fa-bolt callout--danger--icon">&nbsp;</em></p><div class="callout-body"><p>This form <strong>should be used</strong> to log issues relating to Transactions.</p></div>',
			note: noteObject
		},
		'9050844554141': {
			hint: '<p><em class="fa-solid fa-circle-info callout--info--icon">&nbsp;</em></p><div class="callout-body"><p>Please ensure that you provide as much information as possible so that we can help you faster:</p><ul class="form-hint-ul"><li>Details on the issues you are seeing</li><li>Logs for failed API call</li><li>Screenshots of the errors you are seeing</li></ul><p>For more information, please see the following Help Centre article on how to log a Service Incident [VE]: <a href="https://www.google.com">How to log a Service Incident</a></p></div>',
			danger: '<p><em class="fa-solid fa-bolt callout--danger--icon">&nbsp;</em></p><div class="callout-body"><p>This form <strong>should be used</strong> to log issues relating to Transactions.</p></div>',
			note: noteObject
		},
		'8168432431261': {
			hint: '<p><em class="fa-solid fa-circle-info callout--info--icon">&nbsp;</em></p><div class="callout-body"><p>Please provide as much detail as possible in relation to your product queries, as this will help us answer your question as quickly as possible:</p><ul><li>API / Error codes</li><li>Logs</li></ul><p></p></div>',
			note: noteObject
		},
		'8231867511581': {
			hint: '<p><em class="fa-solid fa-circle-info callout--info--icon">&nbsp;</em></p><div class="callout-body"><p>Chargebacks & Disputes Hint</p></div>',
			note: noteObject
		},
		'8811613330077': {
			hint: '<p><em class="fa-solid fa-circle-info callout--info--icon">&nbsp;</em></p><div class="callout-body"><p>Using this form you can <b>request access</b> to a different Paymentology service:</p><ul class="form-hint-ul"><li>PayControl (for <em>Banking.Live</em>)</li><li>Support Portal</li></ul><p>Please provide the email(s) for users requiring access.</p></div>',
			note: noteObject
		},
		'8597589597725': {
			hint: '<p><em class="fa-solid fa-circle-info callout--info--icon">&nbsp;</em></p><div class="callout-body"><p>Chargeback & Dispute Hint</p></div>',
			note: noteObject
		},
		'26939464480796': {
			note: '<p><em class="fa-solid fa-circle-info callout--note--icon">&nbsp;</em></p><div class="callout-body"><p><strong>Required documentation by cardholder status</strong></p><ul><li><strong>Disbursement:</strong> Asylum Seeker Document or Refugee Permit</li><li><strong>Wallet:</strong> Foreign Passport (non-sanctioned countries). No work permit required.</li><li><strong>FICA light:</strong> Foreign Passport (non-sanctioned countries), South African ID, Asylum Seeker Document, or Refugee Permit. No proof of address or work permit required.</li><li><strong>Full FICA:</strong> Foreign Passport and Work Permit, or South African ID. No proof of address required.</li></ul></div>',
			warning: '<p><em class="fa-solid fa-triangle-exclamation callout--warning--icon">&nbsp;</em></p><div class="callout-body"><p>Failure to include copies of the required documentation will result in delays on processing your request.</p></div>',
		},
		'29796154894748': {
			note: '<em class="fa-solid fa-circle-info callout--note--icon"></em><div class="callout-body"><p>The specified contact details will be used for the delivery.</p></div>',
		},
		'26939986818972': {
			note: noteObject
		},
		'26994830585372': {
			note: noteObject
		},
		'26995027162652': {
			warning: '<p><em class="fa-solid fa-triangle-exclamation callout--warning--icon">&nbsp;</em></p><div class="callout-body"><p>Failure to include copies of the required documentation will result in delays on processing your request.</p></div>',
			note: noteObject
		},
		'26995056699932': {
			note: noteObject
		},
		'28643669349660': {
			hint: '<p><em class="fa-solid fa-circle-info callout--info--icon">&nbsp;</em></p><div class="callout-body"><p>To facilitate this request, please attach the following supporting documents when submitting your request:</p><ul><li>Proof of Payment</li><li><em class="fa-solid fa-link" style="color:#61A5FF;">&nbsp;&nbsp;</em><a href="https://help.paymentology.com/hc/en-us/article_attachments/28699625430172" target="_blank" class="attachment-meta-item meta-data" title="Download">Manual Load Indemnity Form</a></li></ul></p></div>',
			warning: '<p><em class="fa-solid fa-triangle-exclamation callout--warning--icon">&nbsp;</em></p><div class="callout-body"><p>Failure to include the Proof of Payment and completed indemnity form will result in delays on processing your request.</p></div>',
			note: noteObject
		}
	};

	const calloutsForForm = formCallouts[formId];
	if (!calloutsForForm) {
		return;
	}

	Object.entries(calloutsForForm).forEach(([type, content]) => {
		const element = calloutElements[type];
		if (!element) {
			return;
		}
		element.classList.remove('hidden');
		element.style.display = 'flex';
		element.innerHTML = content;
	});
}
