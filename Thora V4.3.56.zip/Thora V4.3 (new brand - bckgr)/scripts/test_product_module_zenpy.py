#!/usr/bin/env python3
"""Create controlled Zendesk tickets to investigate Product / Module defaults.

Required environment variables:
  ZENPY_SUBDOMAIN
  ZENPY_EMAIL
  ZENPY_API_TOKEN
  ZENPY_REQUESTER_EMAIL

Usage:
  python3 scripts/test_product_module_zenpy.py        # dry run
  python3 scripts/test_product_module_zenpy.py --send # create tickets
"""

import argparse
import os
import sys

import zenpy
from zenpy.lib.api_objects import Comment, CustomField, Ticket, User


PRODUCT_MODULE_FIELD_ID = 28175955127324
FICA_OR_OBSERVED_FORM_ID = 23856515289628
SERVICE_INCIDENT_FORM_ID = 23677534458396


def required_env(name):
    value = os.environ.get(name)
    if not value:
        raise RuntimeError(f"Missing required environment variable: {name}")
    return value


def ticket_payload(name, form_id, include_product_module):
    custom_fields = [
        CustomField(id=23705181996316, value="urgency_low"),
        CustomField(id=23703988475932, value="area_report"),
    ]
    if include_product_module:
        custom_fields.insert(
            0,
            CustomField(
                id=PRODUCT_MODULE_FIELD_ID,
                value="prod_module_paycredit",
            ),
        )

    return Ticket(
        ticket_form_id=form_id,
        subject=f"PRODUCT MODULE TEST - {name}",
        comment=Comment(
            body=(
                "Controlled Product / Module investigation test. "
                f"Case: {name}."
            ),
            public=False,
        ),
        requester=User(email=required_env("ZENPY_REQUESTER_EMAIL")),
        custom_fields=custom_fields,
    )


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--send",
        action="store_true",
        help="Actually create the three Zendesk tickets.",
    )
    args = parser.parse_args()

    credentials = zenpy.Credentials(
        subdomain=required_env("ZENPY_SUBDOMAIN"),
        email=required_env("ZENPY_EMAIL"),
        token=required_env("ZENPY_API_TOKEN"),
    )
    client = zenpy.Zenpy(credentials)

    tests = [
        (
            "FICA_PAYCREDIT",
            FICA_OR_OBSERVED_FORM_ID,
            True,
        ),
        (
            "FICA_OMITTED",
            FICA_OR_OBSERVED_FORM_ID,
            False,
        ),
        (
            "SERVICE_INCIDENT_PAYCREDIT",
            SERVICE_INCIDENT_FORM_ID,
            True,
        ),
    ]

    if not args.send:
        print("Dry run; no tickets will be created.")
        for name, form_id, include_product_module in tests:
            field_state = "prod_module_paycredit" if include_product_module else "OMITTED"
            print(f"{name}: form={form_id}, Product / Module={field_state}")
        print("Use --send to create the tickets.")
        return 0

    print("Creating three Zendesk investigation tickets...")
    for name, form_id, include_product_module in tests:
        ticket = client.tickets.create(
            ticket_payload(name, form_id, include_product_module)
        )
        print(
            f"{name}: ticket_id={ticket.ticket.id}, "
            f"form_id={ticket.ticket.ticket_form_id}"
        )

    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as error:
        print(f"ERROR: {error}", file=sys.stderr)
        raise SystemExit(1)
